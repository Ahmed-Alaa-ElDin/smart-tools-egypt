<div>
    <div class="grid grid-cols-12 gap-3">
        
        <div
            class="col-span-12 md:col-span-6 rounded-xl p-3 bg-red-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-3 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 1')); ?></label>
            <select wire:model="selectedSupercategories.0" wire:key="selectedSupercategories.0"
                class="col-span-12 md:col-span-9 rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['selectedSupercategories.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="0">
                    <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                </option>
                <?php $__empty_1 = true; $__currentLoopData = $supercategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($supercategory->id); ?>">
                        <?php echo e($supercategory->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option value="0">
                        <?php echo e(__('admin/sitePages.No supercategories in Database')); ?>

                    </option>
                <?php endif; ?>
            </select>

            <?php $__errorArgs = ['selectedSupercategories.0'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                    <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        

        
        <div
            class="col-span-12 md:col-span-6 rounded-xl p-3 bg-gray-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-3 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 2')); ?></label>
            <select wire:model="selectedSupercategories.1" wire:key="selectedSupercategories.1"
                class="col-span-12 md:col-span-9 rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['selectedSupercategories.1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="0">
                    <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                </option>
                <?php $__empty_1 = true; $__currentLoopData = $supercategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($supercategory->id); ?>">
                        <?php echo e($supercategory->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option value="0">
                        <?php echo e(__('admin/sitePages.No supercategories in Database')); ?>

                    </option>
                <?php endif; ?>
            </select>

            <?php $__errorArgs = ['selectedSupercategories.1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                    <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        

        
        <div
            class="col-span-12 md:col-span-6 rounded-xl p-3 bg-red-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-3 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 3')); ?></label>
            <select wire:model="selectedSupercategories.2" wire:key="selectedSupercategories.2"
                class="col-span-12 md:col-span-9 rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['selectedSupercategories.2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="0">
                    <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                </option>
                <?php $__empty_1 = true; $__currentLoopData = $supercategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($supercategory->id); ?>">
                        <?php echo e($supercategory->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option value="0">
                        <?php echo e(__('admin/sitePages.No supercategories in Database')); ?>

                    </option>
                <?php endif; ?>
            </select>

            <?php $__errorArgs = ['selectedSupercategories.2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                    <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        

        
        <div
            class="col-span-12 md:col-span-6 rounded-xl p-3 bg-gray-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-3 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 4')); ?></label>
            <select wire:model="selectedSupercategories.3" wire:key="selectedSupercategories.3"
                class="col-span-12 md:col-span-9 rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['selectedSupercategories.3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="0">
                    <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                </option>
                <?php $__empty_1 = true; $__currentLoopData = $supercategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($supercategory->id); ?>">
                        <?php echo e($supercategory->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option value="0">
                        <?php echo e(__('admin/sitePages.No supercategories in Database')); ?>

                    </option>
                <?php endif; ?>
            </select>

            <?php $__errorArgs = ['selectedSupercategories.3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                    <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        

        
        <div
            class="col-span-12 md:col-span-6 md:col-start-4 rounded-xl p-3 bg-red-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-3 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 5')); ?></label>
            <select wire:model="selectedSupercategories.4" wire:key="selectedSupercategories.4"
                class="col-span-12 md:col-span-9 rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['selectedSupercategories.4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                <option value="0">
                    <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                </option>
                <?php $__empty_1 = true; $__currentLoopData = $supercategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <option value="<?php echo e($supercategory->id); ?>">
                        <?php echo e($supercategory->name); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <option value="0">
                        <?php echo e(__('admin/sitePages.No supercategories in Database')); ?>

                    </option>
                <?php endif; ?>
            </select>

            <?php $__errorArgs = ['selectedSupercategories.4'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                    <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        
    </div>

    <div class="flex flex-wrap gap-3 justify-around mt-4">
        
        <button wire:click.prevent="save"
            class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Update')); ?></button>
        
        <a href="<?php echo e(route('admin.homepage')); ?>"
            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Back')); ?></a>
    </div>

</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/homepage/top-super-categories.blade.php ENDPATH**/ ?>