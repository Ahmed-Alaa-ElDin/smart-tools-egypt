<div>
    <div class="flex flex-col">
        <div class="py-3 bg-white space-y-6">
            <div class="flex justify-between gap-6 items-center">


                
                <div class="mt-1 flex rounded-md shadow-sm">
                    <span
                        class="inline-flex items-center px-3 ltr:rounded-l-md rtl:rounded-r-md border border-r-0 border-gray-300 bg-gray-50 text-center text-gray-500 text-sm">
                        <span class="material-icons">
                            search
                        </span> </span>
                    <input type="text" name="company-website" id="company-website" wire:model='search'
                        class="focus:ring-primary focus:border-primary flex-1 block w-full rounded-none ltr:rounded-r-md rtl:rounded-l-md sm:text-sm border-gray-300"
                        placeholder="<?php echo e(__('admin/deliveriesPages.Search ...')); ?>">
                </div>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Force Delete Country')): ?>
                    <div class="ltr:text-right rtl:text-left">
                        <a href="<?php echo e(route('admin.countries.softDeletedCountries')); ?>"
                            class="btn btn-sm bg-red-600 hover:bg-red-700 focus:bg-red-600 active:bg-red-600 font-bold">
                            <span class="material-icons rtl:ml-2 ltr:mr-2">
                                delete_forever
                            </span>
                            <?php echo e(__('admin/deliveriesPages.Deleted Countries')); ?></a>
                    </div>
                <?php endif; ?>

                
                <div class="form-inline justify-end my-2">
                    <?php echo e(__('pagination.Show')); ?> &nbsp;
                    <select wire:model='perPage' class="form-control w-auto px-3 cursor-pointer">
                        <option>5</option>
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                    &nbsp; <?php echo e(__('pagination.results')); ?>

                </div>
            </div>
        </div>
        <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">

                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">
                    <table class="min-w-full divide-y divide-gray-200">
                        
                        <thead class="bg-gray-50">
                            <tr>

                                
                                <th wire:click="sortBy('name')" scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer select-none">
                                    <?php echo e(__('admin/deliveriesPages.Name')); ?> &nbsp;
                                    <?php echo $__env->make('partials._sort_icon', [
                                        'field' => 'name->' . session('locale'),
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </th>

                                
                                <th wire:click="sortBy('governorates_count')" scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer select-none">
                                    <?php echo e(__('admin/deliveriesPages.Governorates No.')); ?>

                                    <?php echo $__env->make('partials._sort_icon', [
                                        'field' => 'governorates_count',
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </th>

                                
                                <th wire:click="sortBy('cities_count')" scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer select-none">
                                    <?php echo e(__('admin/deliveriesPages.Cities No.')); ?>

                                    <?php echo $__env->make('partials._sort_icon', [
                                        'field' => 'cities_count',
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </th>

                                
                                <th wire:click="sortBy('users_count')" scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer select-none">
                                    <?php echo e(__('admin/deliveriesPages.Users No.')); ?>

                                    <?php echo $__env->make('partials._sort_icon', [
                                        'field' => 'users_count',
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </th>

                                
                                <th wire:click="sortBy('deliveries_count')" scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer select-none">
                                    <?php echo e(__('admin/deliveriesPages.Delivery Comp. No.')); ?>

                                    <?php echo $__env->make('partials._sort_icon', [
                                        'field' => 'deliveries_count',
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </th>

                                
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider select-none">
                                    <?php echo e(__('admin/deliveriesPages.Manage')); ?>

                                    <span class="sr-only"><?php echo e(__('admin/deliveriesPages.Manage')); ?></span>
                                </th>
                            </tr>
                        </thead>

                        
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                
                                <tr>
                                    <td class="px-6 py-2 whitespace-nowrap">
                                        <div class="flex items-center content-center justify-center">
                                            <div class="text-sm font-medium text-gray-900">
                                                <?php echo e($country->name); ?>

                                            </div>
                                        </div>
                                    </td>

                                    
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <?php if($country->governorates_count): ?>
                                            <a href="<?php echo e(route('admin.countries.governoratesCountry', [$country->id])); ?>"
                                                title="<?php echo e(__('admin/deliveriesPages.View')); ?>"
                                                class="m-auto text-sm bg-view hover:bg-viewHover rounded p-1 max-w-max h-9 flex flex-row justify-center items-center content-center">
                                                <span class="bg-white rounded py-1 px-2">
                                                    <?php echo e($country->governorates_count); ?>

                                                </span>

                                                <span class="material-icons text-lg text-white p-1 ltr:ml-1 rtl:mr-1">
                                                    visibility
                                                </span>
                                            </a>
                                        <?php else: ?>
                                            <div
                                                class="m-auto text-sm bg-red-400 rounded p-1 max-w-max h-9 flex flex-row justify-center items-center content-center">
                                                <span class="bg-white rounded py-1 px-2">0</span>
                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <?php if($country->cities_count): ?>
                                            <a href="<?php echo e(route('admin.countries.citiesCountry', [$country->id])); ?>"
                                                title="<?php echo e(__('admin/deliveriesPages.View')); ?>"
                                                class="m-auto text-sm bg-view hover:bg-viewHover rounded p-1 max-w-max h-9 flex flex-row justify-center items-center content-center">
                                                <span class="bg-white rounded py-1 px-2">
                                                    <?php echo e($country->cities_count); ?>

                                                </span>

                                                <span class="material-icons text-lg text-white p-1 ltr:ml-1 rtl:mr-1">
                                                    visibility
                                                </span>
                                            </a>
                                        <?php else: ?>
                                            <div
                                                class="m-auto text-sm bg-red-400 rounded p-1 max-w-max h-9 flex flex-row justify-center items-center content-center">
                                                <span class="bg-white rounded py-1 px-2">0</span>
                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <?php if($country->users_count): ?>
                                            <a href="<?php echo e(route('admin.countries.usersCountry', [$country->id])); ?>"
                                                title="<?php echo e(__('admin/deliveriesPages.View')); ?>"
                                                class="m-auto text-sm bg-view hover:bg-viewHover rounded p-1 max-w-max h-9 flex flex-row justify-center items-center content-center">
                                                <span class="bg-white rounded py-1 px-2">
                                                    <?php echo e($country->users_count); ?>

                                                </span>

                                                <span class="material-icons text-lg text-white p-1 ltr:ml-1 rtl:mr-1">
                                                    visibility
                                                </span>
                                            </a>
                                        <?php else: ?>
                                            <div
                                                class="m-auto text-sm bg-red-400 rounded p-1 max-w-max h-9 flex flex-row justify-center items-center content-center">
                                                <span class="bg-white rounded py-1 px-2">0</span>
                                            </div>
                                        <?php endif; ?>
                                    </td>

                                    
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <?php if($country->deliveries_count): ?>
                                            <a href="<?php echo e(route('admin.countries.deliveriesCountry', [$country->id])); ?>"
                                                title="<?php echo e(__('admin/deliveriesPages.View')); ?>"
                                                class="m-auto text-sm bg-view hover:bg-viewHover rounded p-1 max-w-max h-9 flex flex-row justify-center items-center content-center">
                                                <span class="bg-white rounded py-1 px-2">
                                                    <?php echo e($country->deliveries->count()); ?>

                                                </span>

                                                <span class="material-icons text-lg text-white p-1 ltr:ml-1 rtl:mr-1">
                                                    visibility
                                                </span>
                                            </a>
                                        <?php else: ?>
                                            <div
                                                class="m-auto text-sm bg-red-400 rounded p-1 max-w-max h-9 flex flex-row justify-center items-center content-center">
                                                <span class="bg-white rounded py-1 px-2">0</span>
                                            </div>
                                        <?php endif; ?>
                                    </td>


                                    <td class="px-6 py-2 whitespace-nowrap text-center text-sm font-medium">

                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Edit Country')): ?>
                                            <a href="<?php echo e(route('admin.countries.edit', [$country->id])); ?>"
                                                title="<?php echo e(__('admin/deliveriesPages.Edit')); ?>" class="m-0">
                                                <span
                                                    class="material-icons p-1 text-lg w-9 h-9 text-white bg-edit hover:bg-editHover rounded">
                                                    edit
                                                </span>
                                            </a>
                                        <?php endif; ?>

                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Deleted Country')): ?>
                                            <a href="#" title="<?php echo e(__('admin/deliveriesPages.Delete')); ?>"
                                                wire:click.prevent="deleteConfirm(<?php echo e($country->id); ?>)"
                                                class="m-0">
                                                <span
                                                    class="material-icons p-1 text-lg w-9 h-9 text-white bg-delete hover:bg-deleteHover rounded">
                                                    delete
                                                </span>
                                            </a>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center py-2 font-bold" colspan="6">
                                        <?php echo e($search == ''? __('admin/deliveriesPages.No data in this table'): __('admin/deliveriesPages.No data available according to your search')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="mt-4">
            <?php echo e($countries->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/countries/countries-datatable.blade.php ENDPATH**/ ?>