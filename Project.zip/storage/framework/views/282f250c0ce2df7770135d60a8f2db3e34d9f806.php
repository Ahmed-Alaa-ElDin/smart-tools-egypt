<section class="top-categories-brands container mb-3 relative overflow-hidden">

    <div class="grid grid-cols-12 gap-3 lg:gap-4">

        
        <div class="col-span-12 lg:col-span-6 rounded p-4">

            
            <div class="flex flex-wrap mb-3 justify-between items-baseline border-b">
                
                <h3 class="h5 font-bold mb-0 text-center">
                    <span
                        class="border-b-2 border-primary pb-3 inline-block"><?php echo e(__('front/homePage.Top Categories')); ?></span>
                </h3>
                

                
                <a href="#"
                    class="btn bg-secondary btn-sm shadow-md font-bold"><?php echo e(__('front/homePage.See All Categories')); ?></a>
                
            </div>
            

            
            <div class="grid grid-cols-6 gap-3">

                
                <div class="col-span-6 md:col-span-3">
                    <a href="#" class="bg-white border block rounded p-2 hover:shadow-md">
                        <div class="grid grid-cols-12 items-center">

                            
                            <div class="col-span-3 text-center">
                                <img src="https://media-exp1.licdn.com/dms/image/C4E03AQFJrYvwS8LG7A/profile-displayphoto-shrink_200_200/0/1618407004394?e=1653523200&v=beta&t=Gd8H3ZhYrH-HerCtXk2yDulMyR1zMaFSBeOJ8rTypmg"
                                    alt="Women Clothing &amp; Fashion" class="img-fluid img rounded lazyloaded">
                            </div>
                            

                            
                            <div class="col-span-7">
                                <div class="truncate font-bold text-center px-3">
                                    Manual Cars
                                </div>
                            </div>
                            

                            
                            <div class="col-span-2 text-center">
                                <span class="material-icons text-primary">
                                    <?php if(session('locale') == 'en'): ?>
                                        chevron_right
                                    <?php else: ?>
                                        chevron_left
                                    <?php endif; ?>
                                </span>
                            </div>
                            

                        </div>
                    </a>
                </div>
                

                
                <div class="col-span-6 md:col-span-3">
                    <a href="#" class="bg-white border block rounded p-2 hover:shadow-md">
                        <div class="grid grid-cols-12 items-center">

                            
                            <div class="col-span-3 text-center">
                                <img src="https://media-exp1.licdn.com/dms/image/C4E03AQFJrYvwS8LG7A/profile-displayphoto-shrink_200_200/0/1618407004394?e=1653523200&v=beta&t=Gd8H3ZhYrH-HerCtXk2yDulMyR1zMaFSBeOJ8rTypmg"
                                    alt="Women Clothing &amp; Fashion" class="img-fluid img rounded lazyloaded">
                            </div>
                            

                            
                            <div class="col-span-7">
                                <div class="truncate font-bold text-center px-3">
                                    Manual Cars
                                </div>
                            </div>
                            

                            
                            <div class="col-span-2 text-center">
                                <span class="material-icons text-primary">
                                    <?php if(session('locale') == 'en'): ?>
                                        chevron_right
                                    <?php else: ?>
                                        chevron_left
                                    <?php endif; ?>
                                </span>
                            </div>
                            

                        </div>
                    </a>
                </div>
                
            </div>
            



        </div>
        

        
        <div class="col-span-12 lg:col-span-6 rounded p-4">

            
            <div class="flex flex-wrap mb-3 justify-between items-baseline border-b">
                
                <h3 class="h5 font-bold mb-0 text-center">
                    <span
                        class="border-b-2 border-primary pb-3 inline-block"><?php echo e(__('front/homePage.Top Brands')); ?></span>
                </h3>
                

                
                <a href="#" class="btn bg-secondary btn-sm shadow-md font-bold"><?php echo e(__('front/homePage.See All Brands')); ?></a>
                
            </div>
            

            
            <div class="grid grid-cols-6 gap-3">

                
                <div class="col-span-6 md:col-span-3">
                    <a href="#" class="bg-white border block rounded p-2 hover:shadow-md">
                        <div class="grid grid-cols-12 items-center">

                            
                            <div class="col-span-3 text-center">
                                <img src="https://media-exp1.licdn.com/dms/image/C4E03AQFJrYvwS8LG7A/profile-displayphoto-shrink_200_200/0/1618407004394?e=1653523200&v=beta&t=Gd8H3ZhYrH-HerCtXk2yDulMyR1zMaFSBeOJ8rTypmg"
                                    alt="Women Clothing &amp; Fashion" class="img-fluid img rounded lazyloaded">
                            </div>
                            

                            
                            <div class="col-span-7">
                                <div class="truncate font-bold text-center px-3">
                                    Manual Cars
                                </div>
                            </div>
                            

                            
                            <div class="col-span-2 text-center">
                                <span class="material-icons text-primary">
                                    <?php if(session('locale') == 'en'): ?>
                                        chevron_right
                                    <?php else: ?>
                                        chevron_left
                                    <?php endif; ?>
                                </span>
                            </div>
                            

                        </div>
                    </a>
                </div>
                

                
                <div class="col-span-6 md:col-span-3">
                    <a href="#" class="bg-white border block rounded p-2 hover:shadow-md">
                        <div class="grid grid-cols-12 items-center">

                            
                            <div class="col-span-3 text-center">
                                <img src="https://media-exp1.licdn.com/dms/image/C4E03AQFJrYvwS8LG7A/profile-displayphoto-shrink_200_200/0/1618407004394?e=1653523200&v=beta&t=Gd8H3ZhYrH-HerCtXk2yDulMyR1zMaFSBeOJ8rTypmg"
                                    alt="Women Clothing &amp; Fashion" class="img-fluid img rounded lazyloaded">
                            </div>
                            

                            
                            <div class="col-span-7">
                                <div class="truncate font-bold text-center px-3">
                                    Manual Cars
                                </div>
                            </div>
                            

                            
                            <div class="col-span-2 text-center">
                                <span class="material-icons text-primary">
                                    <?php if(session('locale') == 'en'): ?>
                                        chevron_right
                                    <?php else: ?>
                                        chevron_left
                                    <?php endif; ?>
                                </span>
                            </div>
                            

                        </div>
                    </a>
                </div>
                

            </div>
            



        </div>
        
    </div>
</section>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/layouts/front/includes/top_categories_brands.blade.php ENDPATH**/ ?>