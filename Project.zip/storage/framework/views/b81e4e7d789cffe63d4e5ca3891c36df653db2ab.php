<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            
            <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb text-sm">
                    <li class="breadcrumb-item hover:text-primary">
                        <a href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('admin/productsPages.Dashboard')); ?>

                        </a>
                    </li>
                    <li class="breadcrumb-item hover:text-primary">
                        <a href="<?php echo e(route('admin.products.index')); ?>"><?php echo e(__('admin/productsPages.All Products')); ?>

                        </a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e(__('admin/productsPages.Edit Product')); ?>

                    </li>
                </ol>
            </nav>

            <section class="row">
                <div class="col-md-12">

                    
                    <div class="card">

                        
                        <div class="card-header card-header-primary">
                            <div class="row">
                                <div class="col-12 ltr:text-left rtl:text-right font-bold self-center text-gray-100">
                                    <p class="">
                                        <?php echo e(__("admin/productsPages.Through this form you can edit product's data")); ?>

                                    </p>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card-body overflow-hidden">

                            
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.products.product-form', ['product_id' => $product])->html();
} elseif ($_instance->childHasBeenRendered('N6RIAbH')) {
    $componentId = $_instance->getRenderedChildComponentId('N6RIAbH');
    $componentTag = $_instance->getRenderedChildComponentTagName('N6RIAbH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('N6RIAbH');
} else {
    $response = \Livewire\Livewire::mount('admin.products.product-form', ['product_id' => $product]);
    $html = $response->html();
    $_instance->logRenderedChild('N6RIAbH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


    
    <script src="<?php echo e(asset('assets/js/plugins/tinymce/tinymce.min.js')); ?>"></script>

    <script>
        // Basic tinumce config
        let options = {
            inline: true,
            plugins: [
                'lists',
                'autolink',
                'advlist',
                'directionality',
                'table',
                'autoresize',
                // 'fullscreen'
            ],
            toolbar: 'ltr rtl | ' +
                'bold italic backcolor fontsizeselect| alignleft aligncenter ' +
                'alignright alignjustify | bullist numlist outdent indent | ' +
                'removeformat',
            statusbar: false,
            menubar: false,
            content_style: '.mce-content-body[data-mce-placeholder]:not(.mce-visualblocks)::before { text-align: center ; width: 100% }'

        }

        // tinymce for Description
        tinymce.init({
            ...options,
            directionality: 'rtl',
            selector: '#description_ar',
            setup: function(editor) {
                editor.on('blur', function(e) {
                    window.livewire.emit('descriptionAr', tinymce.get(e.target.id).getContent())
                });
            }
        });

        // tinymce for Description
        tinymce.init({
            ...options,
            directionality: 'ltr',
            selector: '#description_en',
            setup: function(editor) {
                editor.on('blur', function(e) {
                    window.livewire.emit('descriptionEn', tinymce.get(e.target.id).getContent())
                });
            }
        });

        // tinymce for SEO Description
        tinymce.init({
            ...options,
            directionality: 'rtl',
            selector: '#seo_description',
            setup: function(editor) {
                editor.on('blur', function(e) {
                    window.livewire.emit('descriptionSeo', tinymce.get(e.target.id).getContent())
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', ['activeSection' => 'Products', 'activePage' => '', 'titlePage' =>
__('admin/productsPages.Edit Product')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/admin/products/edit.blade.php ENDPATH**/ ?>