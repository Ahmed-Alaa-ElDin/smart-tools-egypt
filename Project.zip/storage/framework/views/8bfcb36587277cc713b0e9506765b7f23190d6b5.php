<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            
            <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb text-sm">
                    <li class="breadcrumb-item hover:text-primary">
                        <a href="<?php echo e(route('admin.dashboard')); ?>">
                            <?php echo e(__('admin/sitePages.Dashboard')); ?>

                        </a>
                    </li>

                    <li class="breadcrumb-item hover:text-primary">
                        <a href="<?php echo e(route('admin.homepage')); ?>">
                            <?php echo e(__('admin/sitePages.Homepage Control')); ?>

                        </a>
                    </li>

                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e(__("admin/sitePages.Homepage's Top Subcategories")); ?>

                    </li>
                </ol>
            </nav>

            <section class="row">
                <div class="col-md-12">

                    
                    <div class="card">

                        
                        <div class="card-header card-header-primary">
                            <div class="flex justify-between items-center">
                                <div class=" ltr:text-left rtl:text-right font-bold self-center text-gray-100">
                                    <p class="">
                                        <?php echo e(__("admin/sitePages.Here you can manage homepage's top categories")); ?></p>
                                </div>

                                
                                <div class="ltr:text-right rtl:text-left">
                                    <a href="<?php echo e(route('admin.subcategories.create')); ?>"
                                        class="btn btn-sm bg-green-600 hover:bg-green-700 focus:bg-green-600 active:bg-green-600 font-bold">
                                        <span class="material-icons rtl:ml-1 ltr:mr-1">
                                            add
                                        </span>
                                        <?php echo e(__('admin/sitePages.Add Subcategory')); ?></a>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card-body overflow-hidden">

                            
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.homepage.topcategories.top-categories')->html();
} elseif ($_instance->childHasBeenRendered('H59iLiZ')) {
    $componentId = $_instance->getRenderedChildComponentId('H59iLiZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('H59iLiZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('H59iLiZ');
} else {
    $response = \Livewire\Livewire::mount('admin.homepage.topcategories.top-categories');
    $html = $response->html();
    $_instance->logRenderedChild('H59iLiZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            

                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', ['activeSection' => 'Site Control', 'activePage' => '', 'titlePage'
=> __("admin/sitePages.Homepage's Top Subcategories")], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/admin/homepage/topcategories/index.blade.php ENDPATH**/ ?>