<div>
    <form enctype="multipart/form-data">
        
        <div
            class="grid grid-cols-12 gap-x-6 gap-y-2 items-center bg-gray-100 p-2 text-center my-2 justify-items-center	rounded">

            
            <div wire:loading wire:target="photo" class="col-span-12 my-2">
                <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em"
                    preserveAspectRatio="xMidYMid meet" viewBox="0 0 50 50" class="animate-spin inline-block">
                    <path fill="currentColor"
                        d="M41.9 23.9c-.3-6.1-4-11.8-9.5-14.4c-6-2.7-13.3-1.6-18.3 2.6c-4.8 4-7 10.5-5.6 16.6c1.3 6 6 10.9 11.9 12.5c7.1 2 13.6-1.4 17.6-7.2c-3.6 4.8-9.1 8-15.2 6.9c-6.1-1.1-11.1-5.7-12.5-11.7c-1.5-6.4 1.5-13.1 7.2-16.4c5.9-3.4 14.2-2.1 18.1 3.7c1 1.4 1.7 3.1 2 4.8c.3 1.4.2 2.9.4 4.3c.2 1.3 1.3 3 2.8 2.1c1.3-.8 1.2-2.5 1.1-3.8c0-.4.1.7 0 0z" />
                </svg>
                <span> &nbsp;&nbsp; <?php echo e(__('admin/usersPages.Uploading ...')); ?></span>
            </div>

            
            <?php if($temp_path): ?>
                <div class="col-span-12 text-center w-1/2 md:w-1/4 my-2">
                    <img src="<?php echo e($temp_path); ?>" class="rounded-xl">
                </div>
                <div class="col-span-12 text-center">
                    <button class="btn btn-danger btn-sm text-bold"
                        wire:click.prevent='removePhoto'><?php echo e(__('admin/usersPages.Remove / Replace Profile Image')); ?></button>
                </div>
            <?php else: ?>
                <label for="photo" class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center">
                    <?php echo e(__('admin/usersPages.Profile Image')); ?> </label>
                <input
                    class="form-control block w-full md:w-50 px-2 py-1 text-sm font-normal text-gray-700 bg-white bg-clip-padding border border-solid border-gray-300 rounded transition ease-in-out m-0 focus:text-gray-700 focus:bg-white focus:border-blue-600 focus:outline-none col-span-12 md:col-span-10 py-1 rounded text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300"
                    id="photo" type="file" type="image" wire:model="photo">

                <?php $__errorArgs = ['photo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <span class="col-span-12 bg-red-700 rounded text-white shadow px-3 py-1"><?php echo e($message); ?></span>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <?php endif; ?>

        </div>

        
        <div class="grid grid-cols-12 gap-x-6 gap-y-2 items-center bg-red-100 p-2 rounded text-center my-2">
            <label
                class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"><?php echo e(__('admin/usersPages.First Name')); ?></label>
            
            <div class="col-span-6 md:col-span-5">
                <input
                    class="first_input py-1 w-full rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['f_name.ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="text" wire:model.lazy="f_name.ar" placeholder="<?php echo e(__('admin/usersPages.in Arabic')); ?>"
                    tabindex="1" required>
                <?php $__errorArgs = ['f_name.ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="col-span-6 md:col-span-5 ">
                <input
                    class="py-1 w-full rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['f_name.en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="text" wire:model.lazy="f_name.en" placeholder="<?php echo e(__('admin/usersPages.in English')); ?>"
                    tabindex="3">
                <?php $__errorArgs = ['f_name.en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <div class="grid grid-cols-12 gap-x-6 gap-y-2 items-center bg-gray-100 p-2 rounded text-center">
            <label
                class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"><?php echo e(__('admin/usersPages.Last Name')); ?></label>

            
            <div class="col-span-6 md:col-span-5 ">
                <input
                    class="py-1 w-full rounded text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['l_name.ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="text" wire:model.lazy="l_name.ar" placeholder="<?php echo e(__('admin/usersPages.in Arabic')); ?>"
                    tabindex="2" required>
                <?php $__errorArgs = ['l_name.ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>

            
            <div class="col-span-6 md:col-span-5 ">
                <input
                    class="py-1 w-full rounded text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['l_name.en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="text" wire:model.lazy="l_name.en" placeholder="<?php echo e(__('admin/usersPages.in English')); ?>"
                    tabindex="4">
                <?php $__errorArgs = ['l_name.en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            </div>
        </div>

        
        <div class="grid grid-cols-12 gap-x-6 gap-y-2 items-center bg-red-100 p-2 rounded text-center my-2">
            <label
                class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"><?php echo e(__('admin/usersPages.Contacts')); ?></label>

            
            <div class="col-span-12 sm:col-span-8 sm:col-start-3 md:col-span-5">
                <input
                    class="py-1 w-full rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="email" wire:model.lazy="email" placeholder="<?php echo e(__('admin/usersPages.Email')); ?>" dir="ltr"
                    tabindex="5">
                <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            
            <div class="col-span-12 md:col-span-5 grid grid-cols-6 gap-y-2">
                <?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $phone): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <?php if(count($phones) > 1): ?>
                        <div class="col-span-1">
                            <button
                                class=" bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-2 rounded-full shadow btn btn-xs"
                                wire:click.prevent='removePhone(<?php echo e($index); ?>)'
                                title="<?php echo e(__('admin/usersPages.Delete')); ?>">
                                <span class="material-icons">
                                    close
                                </span>
                            </button>
                        </div>
                    <?php endif; ?>

                    
                    <input
                        class="<?php if(count($phones) > 1): ?> col-span-4 <?php else: ?> col-span-5 <?php endif; ?> py-1 w-full rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300"
                        type="text" wire:model.lazy="phones.<?php echo e($index); ?>.phone"
                        placeholder="<?php echo e(__('admin/usersPages.Phone')); ?>" dir="ltr" tabindex="6">

                    
                    <div class="col-span-1  flex flex-column justify-center items-center gap-1">
                        <label for="defaultPhone<?php echo e($index); ?>"
                            class="text-xs text-black m-0 cursor-pointer"><?php echo e(__('admin/usersPages.Default')); ?></label>
                        <input type="radio" id="defaultPhone<?php echo e($index); ?>" wire:model.lazy="defaultPhone"
                            value="<?php echo e($index); ?>"
                            class="appearance-none checked:bg-primary outline-none ring-0 cursor-pointer">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                <?php $__errorArgs = ['phones.*.phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-6 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <?php $__errorArgs = ['defaultPhone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-3 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                
                <button
                    class="col-start-3 col-span-2 bg-rose-500 hover:bg-rose-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm text-center text-xs"
                    wire:click.prevent="addPhone" title="<?php echo e(__('admin/usersPages.Add')); ?>">
                    <span class="material-icons rtl:ml-1 ltr:mr-1">
                        add
                    </span>
                    <?php echo e(__('admin/usersPages.Add')); ?></button>
            </div>
        </div>

        
        <div class="grid grid-cols-12 gap-x-6 gap-y-2 items-center bg-gray-100 p-2 rounded text-center">
            <label
                class="col-span-12 lg:col-span-2 text-black font-bold m-0 text-center"><?php echo e(__('admin/usersPages.Other Information')); ?></label>

            <div class="col-span-12 lg:col-span-10 grid grid-cols-12 gap-x-4 gap-y-2 items-center">
                
                <div
                    class="col-span-12 sm:col-span-6  xl:col-span-3 py-1 grid grid-cols-3 gap-x-4 gap-y-2 items-center">
                    <label for="gender"
                        class="col-span-1 select-none cursor-pointer text-black font-medium m-0"><?php echo e(__('admin/usersPages.Gender')); ?></label>

                    <div class="col-span-2">
                        <select
                            class="col-span-2 rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="gender" id="gender" tabindex="7">
                            <option value="0"><?php echo e(__('admin/usersPages.Male')); ?></option>
                            <option value="1"><?php echo e(__('admin/usersPages.Female')); ?></option>
                        </select>
                        <?php $__errorArgs = ['gender'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div
                    class="col-span-12 sm:col-span-6  xl:col-span-3 py-1 grid grid-cols-3 gap-x-4 gap-y-2 items-center">
                    <label for="role"
                        class="col-span-1 select-none cursor-pointer text-black font-medium m-0"><?php echo e(__('admin/usersPages.Role')); ?></label>
                    <div class="col-span-2">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="role" id="role" tabindex="8">
                            <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <option value="<?php echo e($role->id); ?>">
                                    <?php echo e($role->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <option value=""><?php echo e(__('admin/usersPages.No Roles in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['role'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                
                <div
                    class="col-span-12 sm:col-span-12 xl:col-span-6 py-1 grid grid-cols-3 gap-x-4 gap-y-2 items-center">
                    <label for="birth_date"
                        class="col-span-1 select-none cursor-pointer text-black font-medium m-0"><?php echo e(__('admin/usersPages.Birth Date')); ?></label>
                    <div class="col-span-2">
                        <input
                            class="rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            type="date" wire:model.lazy="birth_date" id="birth_date" tabindex="9" required>
                        <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="grid grid-cols-12 gap-x-4 gap-y-2 items-center bg-red-100 p-2 rounded text-center my-2">
            <label
                class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"><?php echo e(__('admin/usersPages.Address')); ?></label>
            
            <div class="grid grid-cols-3 gap-x-4 gap-y-2 col-span-12 md:col-span-10">
                <?php $__currentLoopData = $addresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $address): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-red-200 rounded col-span-3 grid grid-cols-3 gap-x-4 gap-y-2 p-2 ">
                        <div class="col-span-3 flex justify-around bg-red-300 p-2 rounded-xl md:p-1">

                            
                            <div class="flex flex-column md:flex-row justify-center items-center gap-1">
                                <label for="defaultAddress<?php echo e($index); ?>"
                                    class="text-xs text-black m-0 cursor-pointer"><?php echo e(__('admin/usersPages.Default')); ?></label>
                                <input type="radio" id="defaultAddress<?php echo e($index); ?>"
                                    wire:model.lazy="defaultAddress" value="<?php echo e($index); ?>"
                                    class="appearance-none checked:bg-primary outline-none ring-0 cursor-pointer">
                            </div>

                            
                            <?php if(count($addresses) > 1): ?>
                                <div>
                                    <button
                                        class=" bg-red-500 hover:bg-red-700 text-white font-bold py-1 px-4 rounded-full shadow btn btn-xs"
                                        wire:click.prevent='removeAddress(<?php echo e($index); ?>)'
                                        title="<?php echo e(__('admin/usersPages.Delete')); ?>"><span class="material-icons">
                                            close
                                        </span>
                                    </button>
                                </div>
                            <?php endif; ?>

                        </div>

                        
                        <div class="col-span-3 lg:col-span-1 grid grid-cols-3 items-center">
                            <label class="col-span-1 select-none cursor-pointer text-black font-medium m-0 mx-3"
                                for="country<?php echo e($index); ?>"><?php echo e(__('admin/usersPages.Country')); ?></label>
                            <select
                                class="col-span-2 w-full py-1 rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300"
                                wire:model='addresses.<?php echo e($index); ?>.country_id'
                                wire:change='$emit("countryUpdated",<?php echo e($index); ?>)'
                                id="country<?php echo e($index); ?>">
                                <?php $__empty_1 = true; $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <option value=""><?php echo e(__('admin/usersPages.No Countries in Database')); ?></option>
                                <?php endif; ?>
                            </select>
                        </div>

                        
                        <div class="col-span-3 lg:col-span-1 grid grid-cols-3 items-center">
                            <label
                                class="col-span-1 rtl:text-xs select-none cursor-pointer text-black font-medium m-0 mx-3"
                                for="governorate<?php echo e($index); ?>"><?php echo e(__('admin/usersPages.Governorate')); ?></label>
                            <select
                                class="col-span-2 w-full py-1 rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300"
                                wire:model='addresses.<?php echo e($index); ?>.governorate_id'
                                id="governorate<?php echo e($index); ?>"
                                wire:change='$emit("governorateUpdated",<?php echo e($index); ?>)'>
                                <?php $__empty_1 = true; $__currentLoopData = $governorates[$index]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $governorate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($governorate['id']); ?>">
                                        <?php echo e($governorate['name'][session('locale')]); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php if($country == null): ?>
                                        <option value=""><?php echo e(__('admin/usersPages.Please Choose Country First')); ?>

                                        </option>
                                    <?php else: ?>
                                        <option value=""><?php echo e(__('admin/usersPages.No Governorates in Database')); ?>

                                        </option>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </select>
                        </div>

                        
                        <div class="col-span-3 lg:col-span-1 grid grid-cols-3 items-center">
                            <label class="col-span-1 select-none cursor-pointer text-black font-medium m-0 mx-3"
                                for="city<?php echo e($index); ?>"><?php echo e(__('admin/usersPages.City')); ?></label>

                            <select
                                class="col-span-2 w-full py-1 rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300"
                                wire:model='addresses.<?php echo e($index); ?>.city_id' id="city<?php echo e($index); ?>"
                                wire:change='$emit("cityUpdated",<?php echo e($index); ?>)'>
                                <?php $__empty_1 = true; $__currentLoopData = $cities[$index]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <option value="<?php echo e($city['id']); ?>"><?php echo e($city['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php if($addresses[$index]['governorate_id'] == null): ?>
                                        <option value=""><?php echo e(__('admin/usersPages.Please Choose Governorate First')); ?>

                                        </option>
                                    <?php else: ?>
                                        <option value=""><?php echo e(__('admin/usersPages.No Cities in Database')); ?></option>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </select>
                        </div>

                        
                        <div class="details col-span-3 grid grid-cols-6 justify-between items-center m-0">
                            <label
                                class="col-span-2 lg:col-span-1 select-none cursor-pointer text-black font-medium m-0 mx-3"
                                for="details<?php echo e($index); ?>"><?php echo e(__('admin/usersPages.Address Details')); ?></label>
                            <textarea id="details<?php echo e($index); ?>" rows="2"
                                wire:model.lazy="addresses.<?php echo e($index); ?>.details" dir="rtl"
                                placeholder="<?php echo e(__('admin/usersPages.Please mention the details of the address such as street name, building number, ... etc.')); ?>"
                                class="col-span-4 lg:col-span-5 w-full py-1 rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 overflow-hidden"></textarea>
                        </div>

                        
                        <div class="special_marque col-span-3 grid grid-cols-6 justify-between items-center">
                            <label
                                class="col-span-2 lg:col-span-1 select-none cursor-pointer text-black font-medium m-0 mx-3"
                                for="special_marque<?php echo e($index); ?>"><?php echo e(__('admin/usersPages.Special Marque')); ?></label>
                            <textarea id="special_marque<?php echo e($index); ?>" rows="2"
                                wire:model.lazy="addresses.<?php echo e($index); ?>.special_marque" dir="rtl"
                                placeholder="<?php echo e(__('admin/usersPages.Please mention any special marque such as mosque, grocery, ... etc.')); ?>"
                                class="col-span-4 lg:col-span-5 w-full py-1 rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300"></textarea>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <?php $__errorArgs = ['addresses.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div
                        class="inline-block mt-2 col-span-3 md:col-span-1 md:col-start-2 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <?php $__errorArgs = ['defaultAddress'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div
                        class="inline-block mt-2 col-span-3 md:col-span-1 md:col-start-2 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>


                
                <button
                    class="col-start-2 col-span-1 bg-rose-500 hover:bg-rose-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm text-center text-xs"
                    wire:click.prevent="addAddress" title="<?php echo e(__('admin/usersPages.Add')); ?>"> <span
                        class="material-icons rtl:ml-1 ltr:mr-1">
                        add
                    </span>
                    <?php echo e(__('admin/usersPages.Add')); ?></button>
            </div>
        </div>

        
        <div class="grid grid-cols-12 gap-x-6 gap-y-2 items-center bg-yellow-100 p-2 rounded text-center">
            <label
                class="col-span-12 text-black font-bold m-0 text-center"><?php echo e(__('admin/usersPages.Password Notification')); ?></label>
        </div>

        
        <div class="flex flex-wrap gap-3 justify-around mt-4">
            
            <button type="button" wire:click.prevent="save"
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/usersPages.Save')); ?></button>
            
            <button type="button" wire:click.prevent="save('true')"
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/usersPages.Save and Add New User')); ?></button>
            
            <a href="<?php echo e(route('admin.users.index')); ?>"
                class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/usersPages.Back')); ?></a>
        </div>

    </form>
</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/users/add-user-form.blade.php ENDPATH**/ ?>