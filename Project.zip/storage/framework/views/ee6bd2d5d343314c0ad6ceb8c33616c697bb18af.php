<div>
    
    <?php if (isset($component)) { $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Waiting::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.waiting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\Waiting::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8)): ?>
<?php $component = $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8; ?>
<?php unset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8); ?>
<?php endif; ?>
    

    <div class="grid grid-cols-12 gap-3">

        
        <div class="col-span-12 rounded-xl p-3 bg-red-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 1')); ?></label>
            
            <div class="col-span-12 md:col-span-10 grid grid-cols-12 gap-3">
                
                <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                    <select
                        class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.0.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        wire:model.lazy="items.0.supercategory_id" wire:change="supercategoryUpdated(0)" required>
                        <?php if($items[0]['supercategories']): ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                            </option>
                            <?php $__currentLoopData = $items[0]['supercategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supercategory['id']); ?>">
                                    <?php echo e($supercategory['name'][session('locale')]); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.No Supercategories in the database')); ?>

                            </option>
                        <?php endif; ?>
                    </select>

                    <?php $__errorArgs = ['items.0.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                            <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                

                
                <?php if($items[0]['supercategory_id']): ?>
                    <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.0.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.0.category_id" wire:change="categoryUpdated(0)" required>
                            <?php if($items[0]['categories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a category')); ?>

                                </option>
                                <?php $__currentLoopData = $items[0]['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['id']); ?>">
                                        <?php echo e($category['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Categories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.0.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[0]['category_id']): ?>
                    <div
                        class="col-span-12 sm:col-span-6 md:col-span-4 sm:col-start-4 md:col-start-0 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.0.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.0.subcategory_id" required>
                            <?php if($items[0]['subcategories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a subcategory')); ?>

                                </option>
                                <?php $__currentLoopData = $items[0]['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory['id']); ?>">
                                        <?php echo e($subcategory['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Subcategories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.0.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[0]['subcategory_id']): ?>
                    <div class="col-span-12 text-center">
                        <a href="<?php echo e(route('admin.subcategories.edit', ['subcategory' => $items[0]['category_id']])); ?>"
                            target="_blank"
                            class="bg-edit hover:bg-editHover text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Edit Subcategory')); ?></a>
                    </div>
                <?php endif; ?>
                


            </div>
            
        </div>
        

        
        <div class="col-span-12 rounded-xl p-3 bg-gray-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 2')); ?></label>
            
            <div class="col-span-12 md:col-span-10 grid grid-cols-12 gap-3">
                
                <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                    <select
                        class="rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['items.1.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        wire:model.lazy="items.1.supercategory_id" wire:change="supercategoryUpdated(1)" required>
                        <?php if($items[1]['supercategories']): ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                            </option>
                            <?php $__currentLoopData = $items[1]['supercategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supercategory['id']); ?>">
                                    <?php echo e($supercategory['name'][session('locale')]); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.No Supercategories in the database')); ?>

                            </option>
                        <?php endif; ?>
                    </select>

                    <?php $__errorArgs = ['items.1.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                            <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                

                
                <?php if($items[1]['supercategory_id']): ?>
                    <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['items.1.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.1.category_id" wire:change="categoryUpdated(1)" required>
                            <?php if($items[1]['categories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a category')); ?>

                                </option>
                                <?php $__currentLoopData = $items[1]['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['id']); ?>">
                                        <?php echo e($category['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Categories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.1.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[1]['category_id']): ?>
                    <div
                        class="col-span-12 sm:col-span-6 md:col-span-4 sm:col-start-4 md:col-start-0 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['items.1.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.1.subcategory_id" required>
                            <?php if($items[1]['subcategories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a subcategory')); ?>

                                </option>
                                <?php $__currentLoopData = $items[1]['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory['id']); ?>">
                                        <?php echo e($subcategory['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Subcategories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.1.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[1]['subcategory_id']): ?>
                    <div class="col-span-12 text-center">
                        <a href="<?php echo e(route('admin.subcategories.edit', ['subcategory' => $items[1]['category_id']])); ?>"
                            target="_blank"
                            class="bg-edit hover:bg-editHover text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Edit Subcategory')); ?></a>
                    </div>
                <?php endif; ?>
                

            </div>
            

        </div>
        

        
        <div class="col-span-12 rounded-xl p-3 bg-red-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 3')); ?></label>
            
            <div class="col-span-12 md:col-span-10 grid grid-cols-12 gap-3">
                
                <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                    <select
                        class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.2.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        wire:model.lazy="items.2.supercategory_id" wire:change="supercategoryUpdated(2)" required>
                        <?php if($items[2]['supercategories']): ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                            </option>
                            <?php $__currentLoopData = $items[2]['supercategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supercategory['id']); ?>">
                                    <?php echo e($supercategory['name'][session('locale')]); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.No Supercategories in the database')); ?>

                            </option>
                        <?php endif; ?>
                    </select>

                    <?php $__errorArgs = ['items.2.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                            <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                

                
                <?php if($items[2]['supercategory_id']): ?>
                    <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.2.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.2.category_id" wire:change="categoryUpdated(2)" required>
                            <?php if($items[2]['categories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a category')); ?>

                                </option>
                                <?php $__currentLoopData = $items[2]['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['id']); ?>">
                                        <?php echo e($category['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Categories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.2.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[2]['category_id']): ?>
                    <div
                        class="col-span-12 sm:col-span-6 md:col-span-4 sm:col-start-4 md:col-start-0 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.2.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.2.subcategory_id" required>
                            <?php if($items[2]['subcategories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a subcategory')); ?>

                                </option>
                                <?php $__currentLoopData = $items[2]['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory['id']); ?>">
                                        <?php echo e($subcategory['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Subcategories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.2.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[2]['subcategory_id']): ?>
                    <div class="col-span-12 text-center">
                        <a href="<?php echo e(route('admin.subcategories.edit', ['subcategory' => $items[2]['category_id']])); ?>"
                            target="_blank"
                            class="bg-edit hover:bg-editHover text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Edit Subcategory')); ?></a>
                    </div>
                <?php endif; ?>
                

            </div>
            

        </div>
        

        
        <div class="col-span-12 rounded-xl p-3 bg-gray-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 4')); ?></label>
            
            <div class="col-span-12 md:col-span-10 grid grid-cols-12 gap-3">
                
                <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                    <select
                        class="rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['items.3.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        wire:model.lazy="items.3.supercategory_id" wire:change="supercategoryUpdated(3)" required>
                        <?php if($items[3]['supercategories']): ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                            </option>
                            <?php $__currentLoopData = $items[3]['supercategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supercategory['id']); ?>">
                                    <?php echo e($supercategory['name'][session('locale')]); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.No Supercategories in the database')); ?>

                            </option>
                        <?php endif; ?>
                    </select>

                    <?php $__errorArgs = ['items.3.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                            <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                

                
                <?php if($items[3]['supercategory_id']): ?>
                    <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['items.3.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.3.category_id" wire:change="categoryUpdated(3)" required>
                            <?php if($items[3]['categories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a category')); ?>

                                </option>
                                <?php $__currentLoopData = $items[3]['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['id']); ?>">
                                        <?php echo e($category['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Categories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.3.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[3]['category_id']): ?>
                    <div
                        class="col-span-12 sm:col-span-6 md:col-span-4 sm:col-start-4 md:col-start-0 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['items.3.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.3.subcategory_id" required>
                            <?php if($items[3]['subcategories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a subcategory')); ?>

                                </option>
                                <?php $__currentLoopData = $items[3]['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory['id']); ?>">
                                        <?php echo e($subcategory['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Subcategories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.3.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[3]['subcategory_id']): ?>
                    <div class="col-span-12 text-center">
                        <a href="<?php echo e(route('admin.subcategories.edit', ['subcategory' => $items[3]['category_id']])); ?>"
                            target="_blank"
                            class="bg-edit hover:bg-editHover text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Edit Subcategory')); ?></a>
                    </div>
                <?php endif; ?>
                

            </div>
            

        </div>
        

        
        <div class="col-span-12 rounded-xl p-3 bg-red-100 grid grid-cols-12 items-center justify-center gap-3">
            <label class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"
                for="country"><?php echo e(__('admin/sitePages.Number 5')); ?></label>
            
            <div class="col-span-12 md:col-span-10 grid grid-cols-12 gap-3">
                
                <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                    <select
                        class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.4.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        wire:model.lazy="items.4.supercategory_id" wire:change="supercategoryUpdated(4)" required>
                        <?php if($items[4]['supercategories']): ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.Choose a supercategory')); ?>

                            </option>
                            <?php $__currentLoopData = $items[4]['supercategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supercategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($supercategory['id']); ?>">
                                    <?php echo e($supercategory['name'][session('locale')]); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <option value="0">
                                <?php echo e(__('admin/sitePages.No Supercategories in the database')); ?>

                            </option>
                        <?php endif; ?>
                    </select>

                    <?php $__errorArgs = ['items.4.supercategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                            <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                

                
                <?php if($items[4]['supercategory_id']): ?>
                    <div class="col-span-12 sm:col-span-6 md:col-span-4 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.4.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.4.category_id" wire:change="categoryUpdated(4)" required>
                            <?php if($items[4]['categories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a category')); ?>

                                </option>
                                <?php $__currentLoopData = $items[4]['categories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category['id']); ?>">
                                        <?php echo e($category['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Categories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.4.category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[4]['category_id']): ?>
                    <div
                        class="col-span-12 sm:col-span-6 md:col-span-4 sm:col-start-4 md:col-start-0 items-center w-full">
                        <select
                            class="rounded w-full cursor-pointer py-1 text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['items.4.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            wire:model.lazy="items.4.subcategory_id" required>
                            <?php if($items[4]['subcategories']): ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.Choose a subcategory')); ?>

                                </option>
                                <?php $__currentLoopData = $items[4]['subcategories']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($subcategory['id']); ?>">
                                        <?php echo e($subcategory['name'][session('locale')]); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <option value="0">
                                    <?php echo e(__('admin/sitePages.No Subcategories in the database')); ?>

                                </option>
                            <?php endif; ?>
                        </select>

                        <?php $__errorArgs = ['items.4.subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                                <?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                <?php endif; ?>
                

                
                <?php if($items[4]['subcategory_id']): ?>
                    <div class="col-span-12 text-center">
                        <a href="<?php echo e(route('admin.subcategories.edit', ['subcategory' => $items[4]['category_id']])); ?>"
                            target="_blank"
                            class="bg-edit hover:bg-editHover text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Edit Subcategory')); ?></a>
                    </div>
                <?php endif; ?>
                

            </div>
            

        </div>
        

    </div>

    <div class="flex flex-wrap gap-3 justify-around mt-4">
        
        <button wire:click.prevent="save"
            class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Update')); ?></button>
        
        <a href="<?php echo e(route('admin.homepage')); ?>"
            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Back')); ?></a>
    </div>

</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/homepage/topcategories/top-categories.blade.php ENDPATH**/ ?>