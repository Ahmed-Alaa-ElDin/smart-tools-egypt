<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            
            <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb text-sm">
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('admin/usersPages.Dashboard')); ?></a></li>
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(__('admin/usersPages.All Users')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('admin/usersPages.Roles Management')); ?>

                    </li>
                </ol>
            </nav>

            <section class="row">
                <div class="col-md-12">

                    
                    <div class="card">

                        
                        <div class="card-header card-header-primary">
                            <div class="flex justify-between">
                                <div class=" ltr:text-left rtl:text-right font-bold self-center text-gray-100">
                                    <p class=""> <?php echo e(__('admin/usersPages.Here you can manage roles')); ?></p>
                                </div>

                                
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Add Role')): ?>
                                    <div class="ltr:text-right rtl:text-left">
                                        <a href="<?php echo e(route('admin.roles.create')); ?>"
                                            class="btn btn-sm bg-green-600 hover:bg-green-700 focus:bg-green-600 active:bg-green-600 font-bold">
                                            <span class="material-icons rtl:ml-1 ltr:mr-1">
                                                add
                                            </span>
                                            <?php echo e(__('admin/usersPages.Add Role')); ?>

                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        
                        <div class="card-body overflow-hidden">

                            
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.roles.roles-datatable')->html();
} elseif ($_instance->childHasBeenRendered('793A9a3')) {
    $componentId = $_instance->getRenderedChildComponentId('793A9a3');
    $componentTag = $_instance->getRenderedChildComponentTagName('793A9a3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('793A9a3');
} else {
    $response = \Livewire\Livewire::mount('admin.roles.roles-datatable');
    $html = $response->html();
    $_instance->logRenderedChild('793A9a3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            

                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


    <script>
        // #### Role Delete ####
        window.addEventListener('swalConfirmDelete', function(e) {
            Swal.fire({
                icon: 'warning',
                text: e.detail.text,
                showDenyButton: true,
                confirmButtonText: e.detail.confirmButtonText,
                denyButtonText: e.detail.denyButtonText,
                denyButtonColor: 'gray',
                confirmButtonColor: 'red',
                focusDeny: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.emit('deleteRole', e.detail.role_id);
                }
            });
        });

        window.addEventListener('swalRoleDeleted', function(e) {
            Swal.fire({
                text: e.detail.text,
                icon: e.detail.icon,
                position: 'top-right',
                showConfirmButton: false,
                toast: true,
                timer: 3000,
                timerProgressBar: true,
            })
        });
        // #### Role Delete ####
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', ['activeSection' => 'Users', 'activePage' => 'Roles Management', 'titlePage' =>
__('admin/usersPages.Roles Management')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/admin/users/roles.blade.php ENDPATH**/ ?>