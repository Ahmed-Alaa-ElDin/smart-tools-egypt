<div>
    
    <?php if (isset($component)) { $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Waiting::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.waiting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\Waiting::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8)): ?>
<?php $component = $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8; ?>
<?php unset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8); ?>
<?php endif; ?>
    
    <div class="flex flex-col gap-3">
        
        <div class="flex justify-between gap-6 items-center">
            
            <div class="mt-1 flex rounded-md shadow-sm">
                <span
                    class="inline-flex items-center px-3 ltr:rounded-l-md rtl:rounded-r-md border border-r-0 border-gray-300 bg-gray-50 text-center text-gray-500 text-sm">
                    <span class="material-icons">
                        search
                    </span> </span>
                <input type="text" name="company-website" id="company-website" wire:model='search'
                    class="focus:ring-primary focus:border-primary flex-1 block w-full rounded-none ltr:rounded-r-md rtl:rounded-l-md sm:text-sm border-gray-300"
                    placeholder="<?php echo e(__('admin/offersPages.Search ...')); ?>">
            </div>

            
            <div class="form-inline justify-end my-2">
                <?php echo e(__('pagination.Show')); ?> &nbsp;
                <select wire:model='perPage' class="form-control w-auto px-3 cursor-pointer">
                    <option>5</option>
                    <option>10</option>
                    <option>25</option>
                    <option>50</option>
                    <option>100</option>
                </select>
                &nbsp; <?php echo e(__('pagination.results')); ?>

            </div>
        </div>
        

        
        <div>
            <ul class="flex flex-wrap justify-center gap-3">
                <?php $__empty_1 = true; $__currentLoopData = $offers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$offer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <li class="flex flex-col gap-2 rounded-xl p-3 <?php if($selected_offer == $offer->id): ?> bg-green-100 border-4 border-green-400
                    <?php else: ?>
                    bg-red-100 <?php endif; ?> cursor-pointer shadow"
                        wire:click="selectOffer(<?php echo e($offer->id); ?>)">

                        
                        <?php if($offer->banner): ?>
                            <div class="w-full select-none">
                                <img src="<?php echo e(asset('storage/images/banners/original/' . $offer->banner)); ?>"
                                    class="rounded-xl w-72 m-auto" draggable="false">
                            </div>
                        <?php endif; ?>
                        

                        
                        <span class="block text-black font-bold text-center select-none"><?php echo e($offer->title); ?></span>
                        

                        
                        <div class="flex flex-wrap gap-2 justify-center items-center select-none">
                            <div
                                class="flex flex-col items-center content-center justify-center bg-green-600 p-1 rounded shadow">
                                <span class="font-bold text-xs mb-1 text-white">
                                    <?php echo e(__('admin/sitePages.Start Date')); ?>

                                </span>
                                <div
                                    class="text-sm font-medium text-gray-900 bg-white p-1 w-100 rounded shadow text-center">
                                    <?php echo e(Carbon\Carbon::parse($offer->start_at)->format('d/m/Y') ?? '00/00/0000'); ?>

                                </div>
                            </div>
                            <div
                                class="flex flex-col items-center content-center justify-center bg-red-600 p-1 rounded shadow">
                                <span class="font-bold text-xs mb-1 text-white">
                                    <?php echo e(__('admin/sitePages.End Date')); ?>

                                </span>
                                <div
                                    class="text-sm font-medium text-gray-900 bg-white p-1 w-100 rounded shadow text-center">
                                    <?php echo e(Carbon\Carbon::parse($offer->expire_at)->format('d/m/Y') ?? '00/00/0000'); ?>

                                </div>
                            </div>
                        </div>
                        
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <li class="font-bold">
                        <?php echo e(__('admin/sitePages.No data available according to your search')); ?>

                    </li>
                <?php endif; ?>

            </ul>
        </div>
        

        
        <div>
            <?php echo e($offers->links()); ?>

        </div>
        
    </div>

</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/homepage/sections/offers-list-form.blade.php ENDPATH**/ ?>