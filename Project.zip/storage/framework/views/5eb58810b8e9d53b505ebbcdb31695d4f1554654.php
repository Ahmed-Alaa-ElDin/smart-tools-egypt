<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            
            <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb text-sm">
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('admin/usersPages.Dashboard')); ?></a></li>
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(__('admin/usersPages.All Users')); ?></a></li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('admin/usersPages.Deleted Users')); ?></li>
                </ol>
            </nav>

            <section class="row">
                <div class="col-md-12">

                    
                    <div class="card">

                        
                        <div class="card-header card-header-primary">
                            <div class="row">
                                <div class="col-12 ltr:text-left rtl:text-right font-bold self-center text-gray-100">
                                    <p class="">
                                        <?php echo e(__('admin/usersPages.Here you can Restore / Permanently delete users')); ?></p>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card-body overflow-hidden">

                            
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.users.deleted-users-datatable')->html();
} elseif ($_instance->childHasBeenRendered('sEXkoLV')) {
    $componentId = $_instance->getRenderedChildComponentId('sEXkoLV');
    $componentTag = $_instance->getRenderedChildComponentTagName('sEXkoLV');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('sEXkoLV');
} else {
    $response = \Livewire\Livewire::mount('admin.users.deleted-users-datatable');
    $html = $response->html();
    $_instance->logRenderedChild('sEXkoLV', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            

                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>


    <script>
        // #### User Force Delete ####
        window.addEventListener('swalConfirm', function(e) {
            Swal.fire({
                icon: e.detail.icon,
                text: e.detail.text,
                confirmButtonText: e.detail.confirmButtonText,
                denyButtonText: e.detail.denyButtonText,
                denyButtonColor: e.detail.denyButtonColor,
                confirmButtonColor: e.detail.confirmButtonColor,
                focusDeny: e.detail.focusDeny,
                showDenyButton: true,
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.emit(e.detail.method, e.detail.user_id);
                }
            });
        });

        window.addEventListener('swalDone', function(e) {
            Swal.fire({
                text: e.detail.text,
                icon: e.detail.icon,
                position: 'top-right',
                showConfirmButton: false,
                toast: true,
                timer: 3000,
                timerProgressBar: true,
            })
        });
        // #### User Force Delete ####


        // #### Restore ####
        window.addEventListener('swalRestore', function(e) {
            Swal.fire({
                icon: 'warning',
                text: e.detail.text,
                showDenyButton: true,
                confirmButtonText: e.detail.confirmButtonText,
                denyButtonText: e.detail.denyButtonText,
                denyButtonColor: 'gray',
                confirmButtonColor: 'green',
                focusDeny: false,
            }).then((result) => {
                if (result.isConfirmed) {
                    Livewire.emit('restoreUser', e.detail.user_id);
                }
            });
        });

        window.addEventListener('swalUserRestored', function(e) {
            Swal.fire({
                text: e.detail.text,
                icon: e.detail.icon,
                position: 'top-right',
                showConfirmButton: false,
                toast: true,
                timer: 3000,
                timerProgressBar: true,
            })
        });
        // #### Restore ####
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', ['activeSection' => 'Users', 'activePage' => 'Deleted Users', 'titlePage' =>
__('admin/usersPages.Deleted Users')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/admin/users/softDeleted.blade.php ENDPATH**/ ?>