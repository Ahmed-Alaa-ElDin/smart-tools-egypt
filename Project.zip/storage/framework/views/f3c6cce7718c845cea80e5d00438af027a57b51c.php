<div class="flex flex-col gap-3">
    
    <?php if (isset($component)) { $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Waiting::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.waiting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\Waiting::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8)): ?>
<?php $component = $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8; ?>
<?php unset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8); ?>
<?php endif; ?>
    

    
    <div class="flex justify-center gap-3 items-center">

        
        <button wire:click.stop.prevent="$set('addProduct',1)"
            class="bg-gray-500 hover:bg-gray-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm">
            <span class="material-icons rtl:ml-1 ltr:mr-1">
                add
            </span>
            <?php echo e(__('admin/sitePages.Add Product to List')); ?>

        </button>
        

    </div>
    

    
    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="flex flex-wrap gap-2 w-100 justify-center items-center <?php if($key % 2 == 0): ?> bg-red-100 <?php else: ?> bg-gray-100 <?php endif; ?> rounded-xl"
            wire:key='product-<?php echo e($key); ?>-<?php echo e($product['id']); ?>'>

            
            <div class="p-2 text-center">
                <div class="text-sm text-gray-900">
                    <?php if($product['rank'] && $product['rank'] != 0 && $product['rank'] <= 11): ?>
                        <div class="flex gap-2 items-center min-w-max">

                            <div>
                                
                                <span
                                    class="material-icons rounded text-white text-lg <?php if($product['rank'] < 12): ?> <?php if($key % 2 == 0): ?> bg-primary <?php else: ?> bg-secondary <?php endif; ?> cursor-pointer
<?php else: ?>
bg-gray-200 <?php endif; ?> select-none"
                                    wire:click="rankDown(<?php echo e($product['id']); ?>)">
                                    expand_more
                                </span>
                                

                                
                                <span
                                    class="material-icons rounded text-white text-lg <?php if($product['rank'] > 1): ?> <?php if($key % 2 == 0): ?> bg-primary <?php else: ?> bg-secondary <?php endif; ?> cursor-pointer
<?php else: ?>
bg-gray-200 <?php endif; ?> select-none"
                                    wire:click="rankUp(<?php echo e($product['id']); ?>)">
                                    expand_less
                                </span>
                                
                            </div>

                            <span class="font-bold">
                                <?php echo e($product['rank']); ?>

                            </span>
                        </div>
                    <?php else: ?>
                        <div class="flex gap-2 items-center min-w-max">

                            <div>
                                
                                <span
                                    class="material-icons rounded text-white text-lg <?php if($product['rank'] < 11): ?> <?php if($key % 2 == 0): ?> bg-primary <?php else: ?> bg-secondary <?php endif; ?> cursor-pointer
<?php else: ?>
bg-gray-200 <?php endif; ?> select-none"
                                    wire:click="rankDown(<?php echo e($product['id']); ?>)">
                                    expand_more
                                </span>
                                

                                
                                <span
                                    class="material-icons rounded text-white text-lg <?php if($product['rank'] > 1): ?> <?php if($key % 2 == 0): ?> bg-primary <?php else: ?> bg-secondary <?php endif; ?> cursor-pointer
<?php else: ?>
bg-gray-200 <?php endif; ?> select-none"
                                    wire:click="rankUp(<?php echo e($product['id']); ?>)">
                                    expand_less
                                </span>
                                
                            </div>

                            <span class="font-bold">
                                0
                            </span>
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            
            <div class="grow p-2 text-center flex items-center gap-2 w-50">
                <div class="flex-shrink-0 h-10 w-10">
                    <?php if($product['thumbnail']): ?>
                        <img class="h-10 w-10 rounded-full"
                            src="<?php echo e(asset('storage/images/products/cropped100/' . $product['thumbnail']['file_name'])); ?>"
                            alt="<?php echo e($product['name'][session('locale')] . 'image'); ?>">
                    <?php else: ?>
                        <div
                            class="h-10 w-10 rounded-full text-white <?php if($key % 2 == 0): ?> bg-primary <?php else: ?> bg-secondary <?php endif; ?> flex justify-center items-center">
                            <span class="material-icons">
                                construction
                            </span>
                        </div>
                    <?php endif; ?>
                </div>
                <span class="truncate">
                    <?php echo e($product['name'][session('locale')]); ?>

                </span>
            </div>


            
            <div class="p-2 text-center">
                <div class="text-sm flex gap-2 ">
                    <?php if($product['under_reviewing']): ?>
                        <span class="bg-yellow-600 px-2 p-1 rounded text-white text-xs">
                            <?php echo e(__('admin/sitePages.Under Reviewing')); ?>

                        </span>
                    <?php elseif($product['final_price'] == $product['base_price']): ?>
                        <div
                            class="flex flex-col items-center content-center justify-center bg-green-600 p-1 rounded shadow">
                            <span class="font-bold text-xs mb-1 text-white">
                                <?php echo e(__('admin/sitePages.Final Price')); ?>

                            </span>
                            <div class="text-sm font-medium text-gray-900 bg-white p-1 w-100 rounded shadow">
                                <?php echo e($product['final_price'] ?? 0); ?>

                                <span class="text-xs">
                                    <?php echo e(__('admin/sitePages. EGP')); ?>

                                </span>
                            </div>
                        </div>
                    <?php else: ?>
                        <div
                            class="flex flex-col items-center content-center justify-center bg-red-600 p-1 rounded shadow">
                            <span class="font-bold text-xs mb-1 text-white">
                                <?php echo e(__('admin/sitePages.Base Price')); ?>

                            </span>
                            <div
                                class="line-through text-sm font-medium text-gray-900 bg-white p-1 w-100 rounded shadow">
                                <?php echo e($product['base_price'] ?? 0); ?>

                                <span class="text-xs">
                                    <?php echo e(__('admin/sitePages. EGP')); ?>

                                </span>
                            </div>
                        </div>
                        <div
                            class="flex flex-col items-center content-center justify-center bg-green-600 p-1 rounded shadow">
                            <span class="font-bold text-xs mb-1 text-white">
                                <?php echo e(__('admin/sitePages.Final Price')); ?>

                            </span>
                            <div class="text-sm font-medium text-gray-900 bg-white p-1 w-100 rounded shadow">
                                <?php echo e($product['final_price'] ?? 0); ?>

                                <span class="text-xs">
                                    <?php echo e(__('admin/sitePages. EGP')); ?>

                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
            


            
            <div class="p-2 text-center">
                <div class="flex flex-col items-center content-center justify-center bg-yellow-600 p-1 rounded shadow">
                    <span class="font-bold text-xs mb-1 text-white">
                        <?php echo e(__('admin/sitePages.Points')); ?>

                    </span>
                    <div class="text-sm font-medium text-gray-900 bg-white p-1 w-100 rounded shadow">
                        <?php echo e($product['points'] ?? 0); ?>

                    </div>
                </div>
            </div>
            

            
            <div class="p-2 text-center text-sm font-medium flex gap-2">

                
                <a href="<?php echo e(route('admin.products.edit', [$product['id']])); ?>" target="_blank"
                    data-title="<?php echo e(__('admin/sitePages.Edit')); ?>" data-toggle="tooltip" data-placement="top"
                    class="m-0">
                    <span class="material-icons p-1 text-lg w-9 h-9 text-white bg-edit hover:bg-editHover rounded">
                        edit
                    </span>
                </a>

                
                <a href="#" data-title="<?php echo e(__('admin/sitePages.Remove from list')); ?>" data-toggle="tooltip"
                    data-placement="top" wire:click.prevent="removeProduct(<?php echo e($product['id']); ?>)"
                    class="m-0">
                    <span
                        class="material-icons p-1 text-lg w-9 h-9 text-white bg-delete hover:bg-deleteHover rounded-circle">
                        close
                    </span>
                </a>
            </div>
            

        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    

    
    <div class="mt-4">
        
    </div>
    


    
    <div wire:click="$set('addProduct',0)"
        class="backdrop-blur-sm cursor-pointer <?php if($addProduct): ?> flex
        <?php else: ?>
        hidden <?php endif; ?> fixed top-0 left-0 z-50 flex justify-center items-center gap-4 w-100 h-100 bg-gray-500/[.4]">
        <div wire:click.stop="$set('addProduct',1)"
            class="cursor-default rounded-xl bg-white w-3/4 md:w-1/2 border-4 border-primary p-3 flex flex-col gap-2">

            <h4 class="h5 md:h4 font-bold mb-2 text-center m-0 event-none">
                <?php echo e(__('admin/sitePages.Add Product to the list')); ?>

            </h4>

            <div class="col-span-12 w-full grid grid-cols-12 gap-x-4 gap-y-2 items-center rounded text-center">
                <label for="product_name"
                    class="col-span-12 md:col-span-3 font-bold m-0 text-center font-bold text-xs text-gray-700 cursor-pointer"><?php echo e(__("admin/sitePages.Product's Name")); ?></label>
                <div class="col-span-12 md:col-span-9">
                    <input
                        class="py-1 w-full rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300"
                        type="text" wire:model.debounce.300ms="searchProduct" onfocus="Livewire.emit('showResults',1);"
                        id="product_name" placeholder="<?php echo e(__("admin/sitePages.Enter Product's Name")); ?>"
                        maxlength="100" autocomplete="off" required>
                    <?php if($searchProduct != '' && $showResult): ?>
                        <div class="relative h-0" wire:key="add-product-321231">
                            <div class="absolute top-0 w-full flex flex-col justify-center items-center">
                                <ul
                                    class="bg-white w-100 z-10 rounded-b-xl overflow-auto border-x border-b border-primary px-1 max-h-48 scrollbar scrollbar-hidden-y">
                                    <?php $__empty_1 = true; $__currentLoopData = $products_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li wire:click.stop.prevent="productSelected(<?php echo e($product['id']); ?>,'<?php echo e($product->name); ?>')"
                                            wire:key="add-product-<?php echo e($key); ?>-<?php echo e($product['id']); ?>"
                                            class="btn bg-white border-b py-3 flex flex-wrap justify-center items-center gap-3 rounded-xl">

                                            
                                            <div
                                                class="flex flex-col justify-start ltr:text-left rtl:text-right gap-2 grow">
                                                <span class="font-bold text-black"><?php echo e($product->name); ?></span>
                                                <span
                                                    class="text-xs font-bold text-gray-500"><?php echo e($product->brand->name); ?></span>
                                            </div>

                                            
                                            <span class="text-xs">
                                                <?php if($product->under_reviewing): ?>
                                                    <span class="bg-yellow-600 px-2 py-1 rounded text-white">
                                                        <?php echo e(__('admin/productsPages.Under Reviewing')); ?>

                                                    </span>
                                                <?php elseif($product->final_price == $product->base_price): ?>
                                                    <span class="bg-green-600 px-2 py-1 rounded text-white">
                                                        <?php echo e($product->final_price); ?>

                                                        <span class="">
                                                            <?php echo e(__('admin/productsPages. EGP')); ?>

                                                        </span>
                                                    </span>
                                                <?php else: ?>
                                                    <span class="line-through bg-red-600 px-2 py-1 rounded text-white">
                                                        <?php echo e($product->base_price); ?>

                                                        <span class="">
                                                            <?php echo e(__('admin/productsPages. EGP')); ?>

                                                        </span>
                                                    </span>
                                                    <span
                                                        class="bg-green-600 px-2 py-1 rounded text-white ltr:ml-1 rtl:mr-1">
                                                        <?php echo e($product->final_price); ?>

                                                        <span class="">
                                                            <?php echo e(__('admin/productsPages. EGP')); ?>

                                                        </span>
                                                    </span>
                                                <?php endif; ?>
                                            </span>

                                            
                                            <span class="bg-yellow-600 px-2 py-1 rounded text-white">
                                                <?php echo e($product->points ?? 0); ?>

                                            </span>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <?php endif; ?>

                                </ul>
                            </div>

                        </div>
                    <?php endif; ?>
                </div>

            </div>


            
            <div class="col-span-12 w-full flex mt-2 justify-around">
                
                <button type="button" wire:click.prevent="add"
                    class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Add')); ?></button>
                
                <a href="#" wire:click.stop.prevent="$set('addProduct',0)"
                    class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Cancel')); ?></a>

            </div>
            
        </div>
    </div>
    

    
    <div class="col-span-12 w-full flex flex-wrap justify-around">
        
        <button type="button" wire:click.prevent="save" wire:loading.attr="disabled"
            class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Save')); ?></button>
        
        <a href="<?php echo e(route('admin.homepage')); ?>"
            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Back')); ?></a>
    </div>
    

</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/homepage/todaydeals/today-deals-list.blade.php ENDPATH**/ ?>