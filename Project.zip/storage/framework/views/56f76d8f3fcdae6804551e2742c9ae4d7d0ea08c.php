<!DOCTYPE html>
<html lang="<?php echo e(LaravelLocalization::getCurrentLocale()); ?>"
    dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(isset($titlePage) ? $titlePage . ' | ' : ''); ?><?php echo e(__('Smart Tools Egypt')); ?></title>

    
    <link rel="apple-touch-icon" sizes="76x76"
        href="<?php echo e(asset('assets/img/logos/smart-tools-logo-fav-only-50.png')); ?>">
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/img/logos/smart-tools-logo-fav-only-50.png')); ?>">

    <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no'
        name='viewport' />

    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">

    <link href="https://fonts.googleapis.com/css2?family=Lato:wght@100;400;700;900&display=swap" rel="stylesheet">
    <?php if(LaravelLocalization::getCurrentLocale() == 'ar'): ?>
        <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;600;700;800;900&display=swap"
            rel="stylesheet">
    <?php endif; ?>

    
     <link href="<?php echo e(asset('assets/front/css/material-dashboard.min.css')); ?>" rel="stylesheet" />
    

    
    

    <?php echo $__env->yieldPushContent('css'); ?>

</head>

<body class="<?php echo e($class ?? ''); ?>">
    <div class="" style="height: 1000px">
<div style="position: sticky; top: 0%">Ahmed</div>
        
        
        

        
        
        

        
        
        


        
        <div class="main-panel">
            

            <?php echo $__env->yieldContent('content'); ?>
            
        </div>
    </div>

    <!--   Core JS Files   -->
    
    

    
    

    <script>
        <?php if(Session::has('success')): ?>
            Swal.fire({
            text:'<?php echo e(Session::get('success')); ?>',
            icon: 'success',
            timer: 3000,
            timerProgressBar: true,
            showConfirmButton: false,
            })
        <?php elseif(Session::has('error')): ?>
            Swal.fire({
            text:'<?php echo e(Session::get('error')); ?>',
            icon: 'error',
            timer: 3000,
            timerProgressBar: true,
            showConfirmButton: false,
            })
        <?php endif; ?>
    </script>

    
    <?php echo $__env->yieldPushContent('js'); ?>
</body>

</html>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/layouts/front/sites.blade.php ENDPATH**/ ?>