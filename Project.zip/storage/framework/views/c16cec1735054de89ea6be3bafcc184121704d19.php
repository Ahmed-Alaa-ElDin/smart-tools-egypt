<div class="flex flex-col gap-3">
    
    <?php if (isset($component)) { $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Waiting::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.waiting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\Waiting::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8)): ?>
<?php $component = $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8; ?>
<?php unset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8); ?>
<?php endif; ?>
    

    <div class="bg-gray-100 rounded shadow p-3 grid grid-cols-12 gap-5 overflow-auto scrollbar scrollbar-hidden">
        
        <div class="col-span-12 w-full grid grid-cols-12 gap-x-4 gap-y-2 items-center text-center">
            <label for="title"
                class="col-span-12 md:col-span-2 cursor-pointer text-black font-bold m-0 text-center select-none"><?php echo e(__("admin/sitePages.Sections's Title")); ?></label>
            
            <div class="col-span-6 md:col-span-5">
                <input
                    class="py-1 w-full rounded text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['title.ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="text" wire:model.lazy="title.ar" id="title" dir="rtl"
                    placeholder="<?php echo e(__('admin/sitePages.in Arabic')); ?>" maxlength="100" required>
                <?php $__errorArgs = ['title.ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            
            <div class="col-span-6 md:col-span-5 ">
                <input
                    class="py-1 w-full rounded text-center border-gray-300 focus:outline-gray-600 focus:ring-gray-300 focus:border-gray-300 <?php $__errorArgs = ['title.en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="text" wire:model.lazy="title.en" placeholder="<?php echo e(__('admin/sitePages.in English')); ?>"
                    dir="ltr" maxlength="100" required>
                <?php $__errorArgs = ['title.en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>
        

        
        <div class="col-span-4 col-start-5 w-full grid grid-cols-6 gap-x-4 gap-y-2 items-center text-center">
            <label for="active"
                class="col-span-6 md:col-span-2 md:col-start-2 cursor-pointer text-black font-bold m-0 text-center select-none"><?php echo e(__('admin/sitePages.Active')); ?></label>

            
            <div class="col-span-6 md:col-span-2 text-center flex items-center justify-center">
                <input class="appearance-none rounded-full checked:bg-secondary outline-none ring-0 cursor-pointer"
                    type="checkbox" id="active" wire:model.lazy="active" value="1">
            </div>

            <?php $__errorArgs = ['active'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="inline-block mt-2 col-span-6 md:col-span-4 bg-red-700 rounded text-white shadow px-3 py-1">
                    <?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        

        
        <div class="col-span-12 flex flex-wrap justify-center items-center gap-4 ">
            <label for="type" class="text-black font-bold m-0 text-center select-none">
                <?php echo e(__('admin/sitePages.Section Type')); ?></label>
            <div class="flex flex-wrap justify-center items-center gap-3">

                
                <label for="products_list" class="text-black m-0 cursor-pointer select-none">
                    <span class="mx-2">
                        <?php echo e(__('admin/sitePages.Products List')); ?>

                    </span>
                    <input class="appearance-none checked:bg-secondary outline-none ring-0 cursor-pointer"
                        id="products_list" type="radio" name="type" wire:model="type" value="0">
                </label>
                

                
                <label for="offer" class="text-black m-0 cursor-pointer select-none">
                    <span class="mx-2">
                        <?php echo e(__('admin/sitePages.Offer')); ?>

                    </span>
                    <input class="appearance-none checked:bg-secondary outline-none ring-0 cursor-pointer" id="offer"
                        type="radio" name="type" wire:model="type" value="1">
                </label>
                

                
                <label for="flash_sale" class="text-black m-0 cursor-pointer select-none">
                    <span class="mx-2">
                        <?php echo e(__('admin/sitePages.Flash Sale')); ?>

                    </span>
                    <input class="appearance-none checked:bg-secondary outline-none ring-0 cursor-pointer"
                        id="flash_sale" type="radio" name="type" wire:model="type" value="2">
                </label>
                

                
                <label for="banners_list" class="text-black m-0 cursor-pointer select-none">
                    <span class="mx-2">
                        <?php echo e(__('admin/sitePages.Banners List')); ?>

                    </span>
                    <input class="appearance-none checked:bg-secondary outline-none ring-0 cursor-pointer"
                        id="banners_list" type="radio" name="type" wire:model="type" value="3">
                </label>
                

            </div>
        </div>
        
    </div>

    <div class="">
        <?php if($type == 0): ?>
            <?php $__errorArgs = ['selected_products'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="flex items-center justify-center" wire:key="selected_products">
                    <div
                        class="inline-block max-w-max m-auto col-span-12 bg-red-700 rounded text-white shadow px-3 py-1 w-full mb-2 text-center">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.homepage.sections.products-list-form', ['products'=>$selected_products??[]])->html();
} elseif ($_instance->childHasBeenRendered('l552740608-0')) {
    $componentId = $_instance->getRenderedChildComponentId('l552740608-0');
    $componentTag = $_instance->getRenderedChildComponentTagName('l552740608-0');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l552740608-0');
} else {
    $response = \Livewire\Livewire::mount('admin.homepage.sections.products-list-form', ['products'=>$selected_products??[]]);
    $html = $response->html();
    $_instance->logRenderedChild('l552740608-0', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
        <?php elseif($type == 1 || $type == 2): ?>
            <?php $__errorArgs = ['selected_offer'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="flex items-center justify-center" wire:key="selected_offer">
                    <div
                        class="inline-block max-w-max m-auto col-span-12 bg-red-700 rounded text-white shadow px-3 py-1 w-full mb-2 text-center">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.homepage.sections.offers-list-form', ['selected_offer'=>$selected_offer])->html();
} elseif ($_instance->childHasBeenRendered('l552740608-1')) {
    $componentId = $_instance->getRenderedChildComponentId('l552740608-1');
    $componentTag = $_instance->getRenderedChildComponentTagName('l552740608-1');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l552740608-1');
} else {
    $response = \Livewire\Livewire::mount('admin.homepage.sections.offers-list-form', ['selected_offer'=>$selected_offer]);
    $html = $response->html();
    $_instance->logRenderedChild('l552740608-1', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
        <?php elseif($type == 3): ?>
            <?php $__errorArgs = ['selected_banners'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="flex items-center justify-center" wire:key="selected_offer">
                    <div
                        class="inline-block max-w-max m-auto col-span-12 bg-red-700 rounded text-white shadow px-3 py-1 w-full mb-2 text-center">
                        <?php echo e($message); ?>

                    </div>
                </div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            
            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.homepage.sections.banners-list-form', ['banners'=>$selected_banners??[]])->html();
} elseif ($_instance->childHasBeenRendered('l552740608-2')) {
    $componentId = $_instance->getRenderedChildComponentId('l552740608-2');
    $componentTag = $_instance->getRenderedChildComponentTagName('l552740608-2');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('l552740608-2');
} else {
    $response = \Livewire\Livewire::mount('admin.homepage.sections.banners-list-form', ['banners'=>$selected_banners??[]]);
    $html = $response->html();
    $_instance->logRenderedChild('l552740608-2', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
            
        <?php endif; ?>
    </div>

    
    <div class="col-span-12 w-full flex flex-wrap justify-around">
        <?php if($section_id != null): ?>
            <button type="button" wire:click.prevent="update" wire:loading.attr="disabled"
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Update')); ?></button>
        <?php else: ?>
            
            <button type="button" wire:click.prevent="save" wire:loading.attr="disabled"
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Save')); ?></button>
            
            <button type="button" wire:click.prevent="save('true')" wire:loading.attr="disabled"
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Save and Add New Section')); ?></button>
        <?php endif; ?>
        
        <a href="<?php echo e(route('admin.homepage')); ?>"
            class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/sitePages.Back')); ?></a>
    </div>
    


</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/homepage/sections/section-form.blade.php ENDPATH**/ ?>