<div class="grid grid-cols-12">
    <h2 class="h3 col-span-12 text-center m-3 font-bold">
        <?php echo e($role->name); ?>

    </h2>

    <div class="table-responsive  col-span-12">
        <table class="w-100 table-bordered table-striped table-hover">
            <thead class="text-center">
                <tr>
                    <th class="bg-primary text-white px-2"><?php echo e(__('admin/usersPages.Permission')); ?></th>
                    <th class="bg-primary text-white px-2"><?php echo e(__('admin/usersPages.Active')); ?></th>
                    <th class="bg-secondary text-white px-2"><?php echo e(__('admin/usersPages.Permission')); ?></th>
                    <th class="bg-secondary text-white px-2"><?php echo e(__('admin/usersPages.Active')); ?></th>
                </tr>
            </thead>
            <tbody class="text-center">
                <?php $__empty_1 = true; $__currentLoopData = $allPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php if($loop->odd): ?>
                        <tr>
                            <td class="px-3 py-2 bg-red-100">
                                <?php echo e($permission->name); ?>

                            </td>
                            <td class="px-3 py-2 bg-red-100">
                                <?php if(in_array($permission->id, $rolesPermissions)): ?>
                                    <span class="text-success pt-1 font-bold material-icons">
                                        check
                                    </span>
                                <?php else: ?>
                                    <span class="text-danger pt-1 font-bold material-icons">
                                        close
                                    </span>
                                <?php endif; ?>
                            </td>
                        <?php else: ?>
                            <td class="px-3 py-2 bg-gray-100"><?php echo e($permission->name); ?>

                            </td>
                            <td class="px-3 py-2 bg-gray-100">
                                <?php if(in_array($permission->id, $rolesPermissions)): ?>
                                    <span class="text-success pt-1 font-bold material-icons">
                                        check
                                    </span>
                                <?php else: ?>
                                    <span class="text-danger pt-1 font-bold material-icons">
                                        close
                                    </span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="text-center py-2 font-bold" colspan="4">
                            <?php echo e(__('admin/usersPages.No permissions in the database')); ?>

                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/roles/roles-permissions-list.blade.php ENDPATH**/ ?>