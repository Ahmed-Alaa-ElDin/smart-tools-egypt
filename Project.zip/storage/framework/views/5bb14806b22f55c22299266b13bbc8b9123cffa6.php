<div>
    
    <?php if (isset($component)) { $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Admin\Waiting::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('admin.waiting'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Admin\Waiting::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8)): ?>
<?php $component = $__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8; ?>
<?php unset($__componentOriginale657cdd71adf9c1e73d66ab71f048847a4fddca8); ?>
<?php endif; ?>
    

    <div class="flex flex-col">
        <div class="py-3 bg-white space-y-6">
            <div class="flex justify-between gap-6 items-center">

                
                <div class="mt-1 flex rounded-md shadow-sm">
                    <span
                        class="inline-flex items-center px-3 ltr:rounded-l-md rtl:rounded-r-md border border-r-0 border-gray-300 bg-gray-50 text-center text-gray-500 text-sm">
                        <span class="material-icons">
                            search
                        </span>
                    </span>
                    <input type="text" name="company-website" id="company-website" wire:model='search'
                        class="focus:ring-primary focus:border-primary flex-1 block w-full rounded-none ltr:rounded-r-md rtl:rounded-l-md sm:text-sm border-gray-300"
                        placeholder="<?php echo e(__('admin/sitePages.Search ...')); ?>">
                </div>

                
                <div class="form-inline justify-end my-2">
                    <?php echo e(__('pagination.Show')); ?> &nbsp;
                    <select wire:model='perPage' class="form-control w-auto px-3 cursor-pointer">
                        <option>5</option>
                        <option>10</option>
                        <option>25</option>
                        <option>50</option>
                        <option>100</option>
                    </select>
                    &nbsp; <?php echo e(__('pagination.results')); ?>

                </div>
            </div>
        </div>
        <div class="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
            <div class="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">

                <div class="shadow overflow-hidden border-b border-gray-200 sm:rounded-lg">

                    <table class="min-w-full divide-y divide-gray-200">
                        
                        <thead class="bg-gray-50">
                            <tr>

                                <th>

                                </th>

                                
                                <th wire:click="sortBy('rank')" scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer select-none">
                                    <div class="min-w-max">
                                        <?php echo e(__('admin/sitePages.Rank')); ?>&nbsp;
                                        <?php echo $__env->make('partials._sort_icon', ['field' => 'rank'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </th>

                                
                                <th wire:click="sortBy('description-><?php echo e(session('locale')); ?>')" scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer select-none">
                                    <?php echo e(__('admin/sitePages.Description')); ?> &nbsp;
                                    <?php echo $__env->make('partials._sort_icon', [
                                        'field' => 'description->' . session('locale'),
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </th>

                                
                                <th wire:click="sortBy('link')" scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer select-none">
                                    <?php echo e(__('admin/sitePages.Link')); ?>

                                    <?php echo $__env->make('partials._sort_icon', [
                                        'field' => 'link',
                                    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </th>

                                
                                <th scope="col"
                                    class="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider select-none">
                                    <?php echo e(__('admin/sitePages.Manage')); ?>

                                    <span class="sr-only"><?php echo e(__('admin/sitePages.Manage')); ?></span>
                                </th>
                            </tr>
                        </thead>

                        
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__empty_1 = true; $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="<?php if($key % 2 == 0): ?> bg-red-100 <?php else: ?> bg-gray-100 <?php endif; ?>">
                                    
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <span wire:click="togglePreview(<?php echo e($banner->id); ?>)"
                                            class="material-icons rounded-circle w-7 h-7 text-center text-white text-lg bg-secondary select-none cursor-pointer">
                                            <?php if(in_array($banner->id, $preview_ids)): ?>
                                                remove
                                            <?php else: ?>
                                                add
                                            <?php endif; ?>
                                        </span>
                                    </td>

                                    
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <div class="text-sm text-gray-900">
                                            <?php if($banner->rank && $banner->rank != 0 && $banner->rank <= 10): ?>
                                                <div class="flex gap-2 items-center">

                                                    <div>
                                                        
                                                        <span
                                                            class="material-icons rounded text-white text-lg <?php if($banner->rank < 11): ?> bg-primary cursor-pointer <?php else: ?> bg-gray-200 <?php endif; ?> select-none"
                                                            wire:click="rankDown(<?php echo e($banner->id); ?>)">
                                                            expand_more
                                                        </span>
                                                        

                                                        
                                                        <span
                                                            class="material-icons rounded text-white text-lg <?php if($banner->rank > 1): ?> bg-primary cursor-pointer <?php else: ?> bg-gray-200 <?php endif; ?> select-none"
                                                            wire:click="rankUp(<?php echo e($banner->id); ?>)">
                                                            expand_less
                                                        </span>
                                                        
                                                    </div>

                                                    <span class="font-bold">
                                                        <?php echo e($banner->rank); ?>

                                                    </span>
                                                </div>
                                            <?php else: ?>
                                                <div class="flex gap-2 items-center">

                                                    <div>
                                                        
                                                        <span
                                                            class="material-icons rounded text-white text-lg <?php if($banner->rank < 10): ?> bg-primary cursor-pointer <?php else: ?> bg-gray-200 <?php endif; ?> select-none"
                                                            wire:click="rankDown(<?php echo e($banner->id); ?>)">
                                                            expand_more
                                                        </span>
                                                        

                                                        
                                                        <span
                                                            class="material-icons rounded text-white text-lg <?php if($banner->rank > 1): ?> bg-primary cursor-pointer <?php else: ?> bg-gray-200 <?php endif; ?> select-none"
                                                            wire:click="rankUp(<?php echo e($banner->id); ?>)">
                                                            expand_less
                                                        </span>
                                                        
                                                    </div>

                                                    <span class="font-bold">
                                                        0
                                                    </span>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </td>

                                    
                                    <td class="px-6 py-2 whitespace-nowrap">
                                        <div class="flex items-center content-center justify-center">
                                            <div class="text-sm font-medium text-gray-900">
                                                <?php echo e($banner->description); ?>

                                            </div>
                                        </div>
                                    </td>

                                    
                                    <td class="px-6 py-2 text-center whitespace-nowrap">
                                        <div class="flex items-center content-center justify-center">
                                            <div class="text-sm font-medium text-gray-900">
                                                <?php echo e($banner->link); ?>

                                            </div>
                                        </div>
                                    </td>

                                    <td class="px-6 py-2 whitespace-nowrap text-center text-sm font-medium">

                                        
                                        <a href="<?php echo e(route('admin.site.banners.edit', [$banner->id])); ?>"
                                            title="<?php echo e(__('admin/sitePages.Edit')); ?>" class="m-0">
                                            <span
                                                class="material-icons p-1 text-lg w-9 h-9 text-white bg-edit hover:bg-editHover rounded">
                                                edit
                                            </span>
                                        </a>

                                        
                                        <a href="#" title="<?php echo e(__('admin/sitePages.Delete')); ?>"
                                            wire:click.prevent="deleteConfirm(<?php echo e($banner->id); ?>)"
                                            class="m-0">
                                            <span
                                                class="material-icons p-1 text-lg w-9 h-9 text-white bg-delete hover:bg-deleteHover rounded">
                                                delete
                                            </span>
                                        </a>
                                    </td>
                                </tr>
                                <?php if(in_array($banner->id, $preview_ids)): ?>
                                    <tr class="<?php if($key % 2 == 0): ?> bg-red-100 <?php else: ?> bg-gray-100 <?php endif; ?>">
                                        <td colspan="5" class="text-center px-6 py-2">
                                            <img src="<?php echo e(asset('storage/images/banners/original/' . $banner->banner_name)); ?>"
                                                class="rounded-xl h-24 m-auto">
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center py-2 font-bold" colspan="5">
                                        <?php echo e($search == ''? __('admin/sitePages.No data in this table'): __('admin/sitePages.No data available according to your search')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="mt-4">
            <?php echo e($banners->links()); ?>

        </div>
    </div>
</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/homepage/banners/banners-datatable.blade.php ENDPATH**/ ?>