<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            
            <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb text-sm">
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('admin/deliveriesPages.Dashboard')); ?></a></li>
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.countries.index')); ?>"><?php echo e(__('admin/deliveriesPages.All Countries')); ?></a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('admin/deliveriesPages.Add Country')); ?>

                    </li>
                </ol>
            </nav>

            <section class="row">
                <div class="col-md-12">

                    
                    <div class="card">

                        
                        <div class="card-header card-header-primary">
                            <div class="row">
                                <div class="col-12 ltr:text-left rtl:text-right font-bold self-center text-gray-100">
                                    <p class="">
                                        <?php echo e(__('admin/deliveriesPages.Through this form you can add new country')); ?>

                                    </p>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card-body overflow-hidden">

                            
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.countries.add-country-form')->html();
} elseif ($_instance->childHasBeenRendered('TrN58Cc')) {
    $componentId = $_instance->getRenderedChildComponentId('TrN58Cc');
    $componentTag = $_instance->getRenderedChildComponentTagName('TrN58Cc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('TrN58Cc');
} else {
    $response = \Livewire\Livewire::mount('admin.countries.add-country-form');
    $html = $response->html();
    $_instance->logRenderedChild('TrN58Cc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', ['activeSection' => 'Delivery System', 'activePage' => '', 'titlePage' =>
__('admin/deliveriesPages.Add Country')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/admin/countries/create.blade.php ENDPATH**/ ?>