<div>
    <form enctype="multipart/form-data">
        <?php echo csrf_field(); ?>

        
        <div class="grid grid-cols-12 gap-x-6 gap-y-2 items-center bg-red-100 p-2 rounded text-center my-2">
            <label
                class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"><?php echo e(__('admin/usersPages.Name')); ?></label>
            
            <div class="col-span-12 sm:col-start-4 sm:col-span-6 md:col-start-auto md:col-span-5">
                <input
                    class="first_input py-1 w-full rounded text-center border-red-300 focus:outline-red-600 focus:ring-red-300 focus:border-red-300 <?php $__errorArgs = ['f_name.ar'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-900 border-2 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                    type="text" wire:model.lazy="name" placeholder="<?php echo e(__('admin/usersPages.Role Name')); ?>"
                    tabindex="1" required>
                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                        <?php echo e($message); ?></div>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
        </div>

        
        <div class="grid grid-cols-12 gap-x-6 gap-y-2 items-center bg-gray-100 p-2 rounded text-center">
            <label
                class="col-span-12 md:col-span-2 text-black font-bold m-0 text-center"><?php echo e(__('admin/usersPages.Permissions')); ?></label>


            <div class="col-span-12 md:col-span-10">

                
                <div class="flex justify-around items-center bg-gray-300 py-1 rounded-xl w-1/2 md:w-1/4 mx-auto mb-2">

                    
                    <div class="text-gray-900 bg-white p-1 m-0 shadow rounded cursor-pointer btn" wire:click="selectAll"
                        title="<?php echo e(__('admin/deliveriesPages.Select All')); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em"
                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" class="inline-block w-6 h-6">
                            <path fill="currentColor"
                                d="M20.496 5.627A2.25 2.25 0 0 1 22 7.75v10A4.25 4.25 0 0 1 17.75 22h-10a2.25 2.25 0 0 1-2.123-1.504l2.097.004H17.75a2.75 2.75 0 0 0 2.75-2.75v-10l-.004-.051V5.627ZM17.246 2a2.25 2.25 0 0 1 2.25 2.25v12.997a2.25 2.25 0 0 1-2.25 2.25H4.25A2.25 2.25 0 0 1 2 17.247V4.25A2.25 2.25 0 0 1 4.25 2h12.997Zm0 1.5H4.25a.75.75 0 0 0-.75.75v12.997c0 .414.336.75.75.75h12.997a.75.75 0 0 0 .75-.75V4.25a.75.75 0 0 0-.75-.75Zm-7.665 7.858L13.47 7.47a.75.75 0 0 1 1.133.976l-.073.084l-4.5 4.5a.75.75 0 0 1-1.056.004L8.9 12.95l-1.5-2a.75.75 0 0 1 1.127-.984l.073.084l.981 1.308L13.47 7.47l-3.89 3.888Z" />
                        </svg>
                    </div>

                    
                    <div class="text-gray-900 bg-white p-1 m-0 shadow rounded cursor-pointer btn"
                        wire:click="deselectAll" title="<?php echo e(__('admin/deliveriesPages.Deselect All')); ?>">
                        <svg xmlns="http://www.w3.org/2000/svg" aria-hidden="true" role="img" width="1em" height="1em"
                            preserveAspectRatio="xMidYMid meet" viewBox="0 0 24 24" class="inline-block w-6 h-6">
                            <path fill="currentColor"
                                d="M20.496 5.627A2.25 2.25 0 0 1 22 7.75v10A4.25 4.25 0 0 1 17.75 22h-10a2.25 2.25 0 0 1-2.123-1.504l2.097.004H17.75a2.75 2.75 0 0 0 2.75-2.75v-10l-.004-.051V5.627ZM17.246 2a2.25 2.25 0 0 1 2.25 2.25v12.997a2.25 2.25 0 0 1-2.25 2.25H4.25A2.25 2.25 0 0 1 2 17.247V4.25A2.25 2.25 0 0 1 4.25 2h12.997Zm0 1.5H4.25a.75.75 0 0 0-.75.75v12.997c0 .414.336.75.75.75h12.997a.75.75 0 0 0 .75-.75V4.25a.75.75 0 0 0-.75-.75Z" />
                        </svg>
                    </div>

                </div>

                
                <div class="table-responsive rounded-xl overflow-hidden">
                    <table class="w-100 table-bordered table-striped table-hover">
                        <thead class="text-center">
                            <tr>
                                <th class="bg-primary text-white px-2"><?php echo e(__('admin/usersPages.Permission')); ?></th>
                                <th class="bg-primary text-white px-2"><?php echo e(__('admin/usersPages.Activate')); ?></th>
                                <th class="bg-secondary text-white px-2"><?php echo e(__('admin/usersPages.Permission')); ?></th>
                                <th class="bg-secondary text-white px-2"><?php echo e(__('admin/usersPages.Activate')); ?></th>
                            </tr>
                        </thead>
                        <tbody class="text-center">
                            <?php $__empty_1 = true; $__currentLoopData = $allPermissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($loop->odd): ?>
                                    <tr>
                                        <td class="px-3 py-2 bg-red-100">
                                            <label for="<?php echo e($permission->name); ?>"
                                                class="cursor-pointer text-black m-0"><?php echo e($permission->name); ?></label>
                                        </td>
                                        <td class="px-3 py-2 bg-red-100">
                                            <input type="checkbox" wire:model='selectedPermissions'
                                                value="<?php echo e($permission->name); ?>" id="<?php echo e($permission->name); ?>"
                                                class="appearance-none border-red-900 rounded-full checked:bg-primary outline-none ring-0 cursor-pointer">
                                        </td>
                                    <?php else: ?>
                                        <td class="px-3 py-2 bg-gray-200">
                                            <label for="<?php echo e($permission->name); ?>"
                                                class="cursor-pointer text-black m-0"><?php echo e($permission->name); ?></label>
                                        </td>
                                        <td class="px-3 py-2 bg-gray-200">
                                            <input type="checkbox" wire:model='selectedPermissions'
                                                value="<?php echo e($permission->name); ?>" id="<?php echo e($permission->name); ?>"
                                                class="appearance-none border-gray-600 rounded-full checked:bg-secondary outline-none ring-0 cursor-pointer">
                                        </td>
                                    </tr>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td class="text-center py-2 font-bold" colspan="4">
                                        <?php echo e(__('admin/usersPages.No permissions in the database')); ?>

                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    <?php $__errorArgs = ['selectedPermissions'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                            <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php $__errorArgs = ['selectedPermissions.*'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <div class="inline-block mt-2 col-span-12 bg-red-700 rounded text-white shadow px-3 py-1">
                            <?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                </div>
            </div>
        </div>

        
        <div class="flex flex-wrap gap-3 justify-around mt-4">
            
            <button type="button" wire:click.prevent="save"
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/usersPages.Save')); ?></button>
            
            <button type="button" wire:click.prevent="save('true')"
                class="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/usersPages.Save and Add New Role')); ?></button>
            
            <a href="<?php echo e(route('admin.roles.index')); ?>"
                class="bg-red-500 hover:bg-red-700 text-white font-bold py-2 px-4 rounded-xl shadow btn btn-sm"><?php echo e(__('admin/usersPages.Back')); ?></a>
        </div>

    </form>
</div>
<?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/livewire/admin/roles/add-role-form.blade.php ENDPATH**/ ?>