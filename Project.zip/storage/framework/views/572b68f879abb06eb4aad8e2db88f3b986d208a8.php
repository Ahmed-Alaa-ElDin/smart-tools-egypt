<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            
            <nav aria-label="breadcrumb" role="navigation">
                <ol class="breadcrumb text-sm">
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.dashboard')); ?>"><?php echo e(__('admin/usersPages.Dashboard')); ?></a></li>
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.users.index')); ?>"><?php echo e(__('admin/usersPages.All Users')); ?></a></li>
                    <li class="breadcrumb-item hover:text-primary"><a
                            href="<?php echo e(route('admin.roles.index')); ?>"><?php echo e(__('admin/usersPages.Roles Management')); ?></a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('admin/usersPages.Add Role')); ?>

                    </li>
                </ol>
            </nav>

            <section class="row">
                <div class="col-md-12">

                    
                    <div class="card">

                        
                        <div class="card-header card-header-primary">
                            <div class="row">
                                <div class="col-12 ltr:text-left rtl:text-right font-bold self-center text-gray-100">
                                    <p class="">
                                        <?php echo e(__('admin/usersPages.Through this form you can add new role')); ?></p>
                                </div>
                            </div>
                        </div>

                        
                        <div class="card-body overflow-hidden">

                            
                            <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.roles.add-role-form')->html();
} elseif ($_instance->childHasBeenRendered('UYhsr0l')) {
    $componentId = $_instance->getRenderedChildComponentId('UYhsr0l');
    $componentTag = $_instance->getRenderedChildComponentTagName('UYhsr0l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('UYhsr0l');
} else {
    $response = \Livewire\Livewire::mount('admin.roles.add-role-form');
    $html = $response->html();
    $_instance->logRenderedChild('UYhsr0l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                            

                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <?php echo \Livewire\Livewire::styles(); ?>

<?php $__env->stopPush(); ?>


<?php $__env->startPush('js'); ?>
    <?php echo \Livewire\Livewire::scripts(); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.admin', ['activeSection' => 'Users', 'activePage' => '', 'titlePage' =>
__('admin/usersPages.Add Role')], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/ahmed/Desktop/Programming/LAMPP/smart-tools-egypt/resources/views/admin/users/createRole.blade.php ENDPATH**/ ?>