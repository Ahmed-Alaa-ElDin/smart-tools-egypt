<div>
    {{-- Loader : Start --}}
    <x-admin.waiting />
    {{-- Loader : End --}}

    {{-- Nothing in the world is as soft and yielding as water. --}}
</div>
