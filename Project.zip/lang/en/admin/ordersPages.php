<?php

return [
    "Dashboard"                                         => "Dashboard",
    "All Orders"                                        => "All Orders",
    "Here you can manage orders"                        => "Here you can manage orders",
    "Add Order"                                         => "Add Order",
    "All Orders"                                        => "All Orders",
    "All Orders"                                        => "All Orders",
];
