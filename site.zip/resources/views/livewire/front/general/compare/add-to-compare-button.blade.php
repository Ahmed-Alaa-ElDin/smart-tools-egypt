<button wire:click="addToCompare({{ $product_id }})" data-title="{{ __('front/homePage.Add to the comparison') }}"
    title="{{ __('front/homePage.Add to the comparison') }}" data-placement="left">
    <span class="material-icons bg-white text-lg p-1 rounded-full border border-gray-200 w-9 h-9 text-center shadow">
        compare_arrows
    </span>
</button>
