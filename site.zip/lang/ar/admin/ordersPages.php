<?php

return [
    "Dashboard"                                         =>      "لوحة التحكم",
    "All Orders"                                        =>      "جميع الطلبات",
    "Here you can manage orders"                        =>      "من خلال هذه الصفحة يمكنك التحكم في الطلبات",
    "Add Order"                                         =>      "إضافة طلب جديد",

];
