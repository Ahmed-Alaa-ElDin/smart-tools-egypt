<?php

return [
    "constants" => [
        'PAGINATION' => 10,
        'DEFAULT_PASSWORD' => 'Password@1234'
    ]
];
